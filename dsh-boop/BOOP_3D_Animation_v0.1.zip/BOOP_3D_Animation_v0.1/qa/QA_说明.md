# 本次验收说明

## 已执行

- `structure-checks.json`：自写结构检查通过，包括 accessor、三角形索引、法线与 morph 顶点数、四元数、循环首尾、无贴图冒充模型。
- `trimesh-import.json`：独立 trimesh importer 成功读入 32 个几何对象。此项只验证几何导入，不验证动画。
- `demo-checks.json`：五态按钮、完成自动回正常、错误持续保持、减少动态、清理资源、手机无横向溢出通过，页面错误列表为空。
- `runtime-checks.json`：早期软件渲染记录；其成功回归项在固定400ms等待下失败。后续采用状态条件等待（3500ms上限）验证通过，记录见 demo-checks，未为了测试修改自动返回业务规则。
- 五态1024/256 PNG 均为RGBA，背景alpha=0；白脸及主体内部保持不透明，边缘有抗锯齿半透明像素。
- 实际绘制环境：本容器 Chromium，软件 SwiftShader / Xvfb。版本见 demo-checks，不以此推断 Surface 或独立显卡性能。

## 未执行 / 不得宣称通过

- 用户真实 DSH Web/Desktop 插件联调。
- Blender 安装、importer及保存 `.blend`。
- `three-controller.js` 的 Three.js 运行验证。
- 独立 Khronos glTF Validator。
- Safari、手机浏览器与真实 GPU 的持续30fps性能。
- 用户对三维轮廓和材质的视觉确认。

## 视觉注意事项

本次为程序建模首版，不能和原确认KV像素一一对应。尾部后视、鳍根和背面为补全设计；当前网格仍可继续雕刻/优化。鳍用形态目标而非刚体穿过身体，已据多轮实际渲染做调整；极端背面/快速多次混合仍建议在宿主灯光下复检。

不得将“程序模型有体积”写成“高保真雕刻已验收”；不得将可运行GLB写成已经交付真实 `.blend`。
