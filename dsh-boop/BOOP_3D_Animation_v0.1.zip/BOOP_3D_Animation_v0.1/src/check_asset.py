"""Structural checks for this asset; not a substitute for Khronos glTF Validator."""
from pathlib import Path
import struct,json,numpy as np,hashlib
R=Path(__file__).resolve().parents[1];data=(R/'model/boop.glb').read_bytes();m,v,l=struct.unpack_from('<4sII',data);assert(m,v,l)==(b'glTF',2,len(data))
JLEN,JT=struct.unpack_from('<I4s',data,12);assert JT==b'JSON';g=json.loads(data[20:20+JLEN]);off=20+JLEN;BLEN,BT=struct.unpack_from('<I4s',data,off);assert BT==b'BIN\x00';b=data[off+8:off+8+BLEN]
def read(i):
 a=g['accessors'][i];vw=g['bufferViews'][a['bufferView']];typ={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']];n={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];begin=vw.get('byteOffset',0)+a.get('byteOffset',0);arr=np.frombuffer(b,dtype=typ,count=a['count']*n,offset=begin).reshape(a['count'],n)
 assert np.isfinite(arr).all();assert begin+arr.nbytes<=len(b);return arr
for i in range(len(g['accessors'])):read(i)
for mesh in g['meshes']:
 for pr in mesh['primitives']:
  n=len(read(pr['attributes']['POSITION']));assert read(pr['indices']).max()<n
  assert len(read(pr['attributes']['NORMAL']))==n
  for target in pr.get('targets',[]):assert all(len(read(idx))==n for idx in target.values())
checks=[]
for anim in g['animations']:
 for ch in anim['channels']:
  sm=anim['samplers'][ch['sampler']];t=read(sm['input'])[:,0];val=read(sm['output']);assert (np.diff(t)>0).all();assert len(t)==len(val)
  if ch['target']['path']=='rotation':assert np.allclose(np.linalg.norm(val,axis=1),1,atol=2e-5)
  if anim['extras']['loop']:assert np.allclose(val[0],val[-1],atol=1e-5),(anim['name'],ch['target'])
 checks.append({'clip':anim['name'],'duration':anim['extras']['duration'],'channels':len(anim['channels']),'loopSeam':'PASS' if anim['extras']['loop'] else 'ONE_SHOT'})
assert len(g['animations'])==8;assert not g.get('images') and not g.get('textures')
report={'result':'PASS','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'checks':['GLB header and chunk lengths','accessor bounds and finite values','triangle index ranges','normal and morph counts','strict animation time order','quaternion normalization','loop endpoint equality','no image billboards or texture dependencies'],'clips':checks,'note':'Custom structural tests. Khronos independent validator and Blender importer NOT_RUN.'}
(R/'qa/structure-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
