"""Import supplied GLB, set up a real Blender studio, save BOOP.blend.
This script is supplied for execution in Blender; it was not run in this build
container, which has no Blender executable. Blender 4.2+ recommended.
Example: blender --background --python src/prepare_blender.py -- --out model/BOOP.blend
"""
import bpy, sys, pathlib, argparse, math
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--glb',default=str(ROOT/'model/boop.glb'));p.add_argument('--out',default=str(ROOT/'model/BOOP.blend'));p.add_argument('--render',action='store_true')
args=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
# This intentionally creates a NEW document. Use a fresh Blender process.
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(pathlib.Path(args.glb).resolve()))
scene=bpy.context.scene;scene.render.fps=30;scene.frame_start=1;scene.frame_end=181
scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=True
scene.render.film_transparent=True;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.resolution_x=1024;scene.render.resolution_y=1024;scene.render.resolution_percentage=100
for obj in bpy.data.objects:
 if obj.type=='MESH':
  for poly in obj.data.polygons:poly.use_smooth=True
# glTF import changes the coordinate convention to Blender Z-up.
target=Vector((0,0,1.64))
def point(obj,at):obj.rotation_euler=(Vector(at)-obj.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(-4.6,-8,3.15));camera=bpy.context.object;camera.name='Studio_Camera';camera.data.type='ORTHO';camera.data.ortho_scale=4.1;point(camera,target);scene.camera=camera
for name,loc,energy,size,color in [('Key',(-4,-5,7),650,5,(1,.97,.92)),('Fill',(4,-2,4),330,4,(.80,.91,1)),('Rim',(1,4,5),500,3,(.60,.89,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.name=name;l.data.energy=energy;l.data.shape='DISK';l.data.size=size;l.data.color=color;point(l,target)
scene.world=bpy.data.worlds.new('Studio_World');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.60,.72,.85,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.25
# Select one coherent imported NLA clip across every object and its shape keys.
def select_clip(name):
 for ob in bpy.data.objects:
  datablocks=[ob]
  if ob.type=='MESH' and ob.data.shape_keys:datablocks.append(ob.data.shape_keys)
  for db in datablocks:
   ad=db.animation_data
   if not ad:continue
   ad.action=None
   for track in ad.nla_tracks:
    track.is_solo=False
    track.mute=not (track.name==name or track.name.startswith(name+'.'))
    for strip in track.strips:
     if strip.action and (strip.action.name==name or strip.action.name.startswith(name+'.')):track.mute=False
select_clip('Idle_Loop');scene.frame_set(1)
readme=bpy.data.texts.new('BOOP_README');readme.write('BOOP v0.1\nImported from genuine animated GLB.\n5 states / 8 clips.\nObject pivots + eye and fin morph targets; no skinning armature.\nSelect corresponding NLA tracks across nodes to preview a state.\nThe package offline player handles entry/loop/success return.\nReference: approved BOOP artwork. Rear and side are interpreted, not scan data.\n')
pathlib.Path(args.out).parent.mkdir(parents=True,exist_ok=True);bpy.ops.wm.save_as_mainfile(filepath=str(pathlib.Path(args.out).resolve()))
if args.render:
 scene.render.filepath=str(ROOT/'images'/'blender-idle.png');bpy.ops.render.render(write_still=True)
print('Saved real Blender project:',args.out)
