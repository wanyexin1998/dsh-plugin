本包包含真实带动画 GLB，而非图片模型。当前制作容器没有 Blender 可执行文件，未生成或伪造 .blend 文件。
用自己的 Blender 4.2+ 可执行：
blender --background --python src/prepare_blender.py -- --out model/BOOP.blend
Windows 示例（根据自己的安装版本修改路径）：
"C:\Program Files\Blender Foundation\Blender 4.2\blender.exe" --background --python src\prepare_blender.py -- --out model\BOOP.blend
脚本新建独立文档，导入 GLB 并配置相机、灯光、透明渲染，随后保存实际 .blend。请不要在未保存的现有 Blender 工程中直接运行。
本脚本未在本次环境运行验证。GLB 已在交付的 WebGL2 播放器中实际加载、五态切换与渲染。
