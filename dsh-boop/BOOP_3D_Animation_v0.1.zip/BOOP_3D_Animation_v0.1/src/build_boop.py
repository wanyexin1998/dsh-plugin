"""BOOP / Wave One — reproducible procedural mesh and glTF 2.0 animation source.
Python 3.10+ and numpy.  No cloud service, textures, character image or API required.
All geometry is authored here; reference illustration is not used as a billboard.
"""
from __future__ import annotations
import json, struct, math, pathlib, sys
import numpy as np
from math import sin, cos, pi, sqrt
ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'model'; OUT.mkdir(exist_ok=True)
G = {'asset':{'version':'2.0','generator':'BOOP procedural character studio v0.1'},'scene':0,'scenes':[{'nodes':[0]}], 'nodes':[], 'meshes':[], 'materials':[], 'buffers':[], 'bufferViews':[], 'accessors':[], 'animations':[]}
B = bytearray(); C = {}; mesh_stats=[]

def accessor(a, typ, component=5126, target=None):
    a=np.asarray(a,dtype={5126:'<f4',5123:'<u2',5125:'<u4'}[component]);
    while len(B)%4:B.append(0)
    off=len(B); data=a.tobytes(); B.extend(data)
    v={'buffer':0,'byteOffset':off,'byteLength':len(data)}
    if target:v['target']=target
    vi=len(G['bufferViews']);G['bufferViews'].append(v)
    count=a.shape[0]
    ac={'bufferView':vi,'componentType':component,'count':count,'type':typ}
    if component==5126:
        ar=a.reshape(count,-1);ac['min']=ar.min(axis=0).tolist();ac['max']=ar.max(axis=0).tolist()
    idx=len(G['accessors']);G['accessors'].append(ac);return idx

def linear(hex):
    c=np.array([int(hex[i:i+2],16)/255 for i in (0,2,4)])
    return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4).tolist()
def mat(name,col,rough=.4,metal=0):
    i=len(G['materials']);G['materials'].append({'name':name,'pbrMetallicRoughness':{'baseColorFactor':linear(col)+[1],'metallicFactor':metal,'roughnessFactor':rough},'doubleSided':False});return i
BLUE=mat('Ocean · satin blue','176D9F',.48)
CYAN=mat('Wave · soft cyan','7AD0E8',.35)
WHITE=mat('Pearl · warm porcelain','F7F4EC',.48)
BLACK=mat('Eyes · polished obsidian','171B22',.17)
GLINT=mat('Eye light · ivory','FFFFFF',.16)
DARK=mat('Blowhole · deep blue','075173',.5)
GROOVE=mat('Belly pleats · pearl shade','E5E5DE',.55)
SIGN=mat('Symbols · blue','1C79B3',.32)


def quat_axis(axis, ang):
    axis=np.array(axis,float);axis/=np.linalg.norm(axis)
    return (list(axis*sin(ang/2))+[cos(ang/2)])
def qmul(a,b):
    x,y,z,w=a;X,Y,Z,W=b
    return [w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z]
def euler(x=0,y=0,z=0):
    return qmul(qmul(quat_axis([0,1,0],y),quat_axis([1,0,0],x)),quat_axis([0,0,1],z))
def align(a,b):
    a=np.array(a,float);b=np.array(b,float);a/=np.linalg.norm(a);b/=np.linalg.norm(b)
    d=float(a@b)
    if d<-.999999:return quat_axis([1,0,0],pi)
    q=np.r_[np.cross(a,b),1+d];q/=np.linalg.norm(q);return q.tolist()
def node(name, parent=None,t=(0,0,0),q=(0,0,0,1),s=(1,1,1),mesh=None,extras=None):
    i=len(G['nodes']);n={'name':name,'translation':list(t),'rotation':list(q),'scale':list(s)}
    if mesh is not None:n['mesh']=mesh
    if extras:n['extras']=extras
    G['nodes'].append(n)
    if parent is not None:G['nodes'][parent].setdefault('children',[]).append(i)
    return i

rig=node('BOOP_Root',extras={'character':'BOOP','version':'0.1','source':'procedural full 3D geometry','notes':'No eyebrows. No mouth. Front +Z. Five UI states. Not a finalized sculpt.'})
body_root=node('CTRL_Body',rig,t=(0,1.32,0));C['body']=body_root

def normals(v,faces):
    v=np.array(v,float);f=np.array(faces,int);ns=np.zeros_like(v)
    n=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]])
    for k in range(3):np.add.at(ns,f[:,k],n)
    norm=np.linalg.norm(ns,axis=1);ns/=np.maximum(norm,1e-10)[:,None]
    return ns

def mesh(name,v,f,material,targets=None):
    v=np.array(v,float);f=np.array(f,int);n=normals(v,f)
    p={'attributes':{'POSITION':accessor(v,'VEC3',target=34962),'NORMAL':accessor(n,'VEC3',target=34962)},'indices':accessor(f.ravel(),'SCALAR',5123 if len(v)<65536 else 5125,target=34963),'material':material,'mode':4}
    m={'name':name,'primitives':[p]}
    if targets:
        p['targets']=[]
        for tv in targets:
            tn=normals(tv,f)
            p['targets'].append({'POSITION':accessor(np.array(tv)-v,'VEC3',target=34962),'NORMAL':accessor(tn-n,'VEC3',target=34962)})
        m['weights']=[0.0]*len(targets);m['extras']={'targetNames':['Blink']}
    idx=len(G['meshes']);G['meshes'].append(m);mesh_stats.append({'name':name,'vertices':len(v),'triangles':len(f)});return idx

def grid_surface(name,fn,material,nu=64,nv=32,wrap=True,parent=body_root,reverse=False,t=(0,0,0),q=(0,0,0,1),s=(1,1,1),target=None):
    v=[fn(j/nv,i/nu) for j in range(nv+1) for i in range(nu if wrap else nu+1)]
    width=nu if wrap else nu+1;fs=[]
    for j in range(nv):
        for i in range(nu):
            a=j*width+i;b=j*width+(i+1)%width;c=(j+1)*width+(i+1)%width;d=(j+1)*width+i
            fs.extend([(a,b,c),(a,c,d)] if not reverse else [(a,c,b),(a,d,c)])
    targets=None if target is None else [[target(p) for p in v]]
    mi=mesh(name,v,fs,material,targets);nd=node(name,parent,t=t,q=q,s=s,mesh=mi)
    return nd

RX,RY,RZ=1.16,1.06,1.08
# A single closed full-volume body; front cap is a conformal offset shell.
def ellipsoid(v,u):
    th=pi*v;ph=2*pi*u
    return (RX*sin(th)*cos(ph),RY*cos(th),RZ*sin(th)*sin(ph))
body=grid_surface('Body_full_volume',ellipsoid,BLUE,80,48,reverse=False)

def bound(ph):return 1.075-.27*sin(ph)+.115*max(0,-sin(ph))**2

def facefn(v,u):
    ph=2*pi*u;th=bound(ph)*v
    return ((RX+.009)*sin(th)*cos(ph),(RY+.009)*sin(th)*sin(ph),(RZ+.009)*cos(th))
face=grid_surface('Face_and_belly',facefn,WHITE,80,38,reverse=True)
# Side wave strokes taper at both ends; separate cyan shell meshes.
for side,(p0,p1) in enumerate([(-1.38,.20),(pi-.20,pi+1.38)]):
    def stripefn(v,u,p0=p0,p1=p1):
        ph=p0+(p1-p0)*u;width=.14*(sin(pi*u)**.65)
        th=bound(ph)+.002+v*width
        return ((RX+.016)*sin(th)*cos(ph),(RY+.016)*sin(th)*sin(ph),(RZ+.016)*cos(th))
    grid_surface('Side_wave_'+str(side),stripefn,CYAN,52,5,wrap=False,reverse=True)

# Smooth tubular/swept volumes for fins, tail and glyphs.
def sweep(name, centers, widths, depths, material, parent=body_root, segments=28):
    ctr=np.array(centers,float);axis=[];v=[]
    for j,c in enumerate(ctr):
        tan=ctr[min(j+1,len(ctr)-1)]-ctr[max(0,j-1)];tan/=max(1e-10,np.linalg.norm(tan))
        ref=np.array([0,0,1.])
        if abs(tan@ref)>.88:ref=np.array([0,1.,0])
        wide=np.cross(tan,ref);wide/=np.linalg.norm(wide);deep=np.cross(tan,wide)
        for i in range(segments):
            a=2*pi*i/segments;v.append(c+widths[j]*cos(a)*wide+depths[j]*sin(a)*deep)
    f=[]
    for j in range(len(ctr)-1):
        for i in range(segments):
            a=j*segments+i;b=j*segments+(i+1)%segments;c=(j+1)*segments+(i+1)%segments;d=(j+1)*segments+i
            f.extend([(a,b,c),(a,c,d)])
    # Reverse if signed volume negative.
    vv=np.array(v);ff=np.array(f)
    vol=np.sum(np.einsum('ij,ij->i',vv[ff[:,0]],np.cross(vv[ff[:,1]],vv[ff[:,2]])))/6
    if vol<0:f=[(a,c,b) for a,b,c in f]
    return node(name,parent,mesh=mesh(name,v,f,material))

def fin(sgn):
    nd=node('CTRL_Fin_'+('L' if sgn<0 else 'R'),body_root,t=(sgn*.98,-.24,.27));C['finL' if sgn<0 else 'finR']=nd
    # A folded pose follows a curved centerline outside the torso. This avoids
    # pushing a rigid paddle through the belly. Shared topology gives one Fold morph.
    def xyz(v,u,fold=False,inflate=1.):
        T=pi*v;k=(1-cos(T))/2;a=2*pi*u
        if fold:
            ps=np.array([[sgn*.01,-.01,.02],[sgn*.62,-.19,.26],[sgn*.52,-.21,.84],[-sgn*.26,-.04,.94]])
        else:
            ps=np.array([[sgn*.01,-.01,.02],[sgn*.26,-.04,.12],[sgn*.64,-.23,.29],[sgn*.79,-.37,.38]])
        center=(1-k)**3*ps[0]+3*(1-k)**2*k*ps[1]+3*(1-k)*k*k*ps[2]+k**3*ps[3]
        tangent=3*(1-k)**2*(ps[1]-ps[0])+6*(1-k)*k*(ps[2]-ps[1])+3*k*k*(ps[3]-ps[2]);tangent/=np.linalg.norm(tangent)
        wide=np.array([0,1.,0])-tangent*tangent[1];wide/=np.linalg.norm(wide);deep=np.cross(tangent,wide)
        return center+inflate*(.245*sin(T)*cos(a)*wide+.145*sin(T)*sin(a)*deep)
    for rim in [False,True]:
        nu=18 if rim else 40;nv=28;width=nu+1 if rim else nu
        verts=[];target=[];ff=[]
        for j in range(nv+1):
            for i in range(width):
                u=((.47 if sgn<0 else .23)+.30*i/nu) if rim else i/nu
                a=xyz(j/nv,u,inflate=1.018 if rim else 1);b=xyz(j/nv,u,True,inflate=1.018 if rim else 1)
                verts.append(a);target.append(b)
        for j in range(nv):
            for i in range(nu):
                a=j*width+i;b=j*width+(i+1)%width;c=(j+1)*width+(i+1)%width;d=(j+1)*width+i
                ff.extend([(a,b,c),(a,c,d)])
        if not rim:
            vv=np.array(verts);fi=np.array(ff);vol=np.einsum('ij,ij->i',vv[fi[:,0]],np.cross(vv[fi[:,1]],vv[fi[:,2]])).sum()
            reverse=vol<0
        if reverse:ff=[(a,c,b) for a,b,c in ff]
        name=('Paddle_cyan_' if rim else 'Paddle_')+('L' if sgn<0 else 'R')
        mi=mesh(name,verts,ff,CYAN if rim else BLUE,[target]);G['meshes'][mi]['extras']['targetNames']=['Fold']
        meshnode=node(name,nd,mesh=mi);G['nodes'][meshnode]['weights']=[0]
        C[('finRim' if rim else 'finMesh')+('L' if sgn<0 else 'R')]=meshnode
fin(-1);fin(1)

# Curved tail peduncle and two compact flukes, all on one pivot.
tail=node('CTRL_Tail',body_root,t=(0,.08,-.81));C['tail']=tail
cs=[];ws=[];ds=[]
for t in np.linspace(0,1,25):
    cs.append((0,.55*t+.10*sin(pi*t),-.65*t));ws.append(.28*(1-t)+.11*t);ds.append(.25*(1-t)+.11*t)
sweep('Tail_stem',cs,ws,ds,BLUE,tail)
for sgn in [-1,1]:
    pts=[];ww=[];dd=[]
    for t in np.linspace(0,1,30):
        pts.append((sgn*.79*t,.53+.40*t+.10*sin(pi*t),-.64-.07*t))
        ww.append(.035+.22*sin(pi*t)**.65 if t<1 else .002);dd.append(.02+.11*sin(pi*t)**.8 if t<1 else .002)
    sweep('Tail_fluke_'+str(sgn),pts,ww,dd,BLUE,tail)
    # smaller cyan back-face strip

# Blowhole socket and asymmetrical sculpted water drops.
def uv_sphere(name,scale,matl,parent=body_root,t=(0,0,0),q=(0,0,0,1),n=40,m=24,target=None):
    def fn(v,u):
        th=pi*v;ph=2*pi*u;return (scale[0]*sin(th)*cos(ph),scale[1]*cos(th),scale[2]*sin(th)*sin(ph))
    return grid_surface(name,fn,matl,n,m,parent=parent,t=t,q=q,reverse=False,target=target)
socket=uv_sphere('Blowhole_socket',(.25,.052,.20),DARK,t=(0,1.027,-.02),n=40,m=12)

def drop(name,root,lean,height,radius,depth,parent=body_root):
    nd=node('CTRL_'+name,parent,t=root)
    # Tip grows from narrow at bottom to a rounded, offset head.
    def fn(v,u):
        a=2*pi*u
        r=radius*(sqrt(max(0,1-((v-.68)/.32)**2)) if v>=.68 else sin(pi*.5*v/.68)**2)
        cx=lean*v**1.6
        return (cx+r*cos(a),height*v,r*(depth/radius)*sin(a))
    grid_surface(name,fn,CYAN,40,34,parent=nd,reverse=True)
    return nd
C['dropL']=drop('Water_large',(-.065,1.015,-.025),-.35,.93,.275,.195)
C['dropR']=drop('Water_small',(.12,1.035,-.025),.27,.60,.167,.135)

# Eyes are real geometry, with one morph per eye for blink/wink.
for sgn in [-1,1]:
    x=sgn*.39;y=.14;z=RZ*sqrt(1-(x/RX)**2-(y/RY)**2)+.020
    q=align([0,0,1],[x/RX**2,y/RY**2,z/RZ**2])
    ep=node('CTRL_Eye_'+('L' if sgn<0 else 'R'),body_root,t=(x,y,z),q=q);C['eyePL' if sgn<0 else 'eyePR']=ep
    def blink(p):
        x,y,z=p;return (x,y*.065+.058*(1-(x/.133)**2),z*.58)
    ey=uv_sphere('Eye_'+('L' if sgn<0 else 'R'),(.133,.257,.048),BLACK,parent=ep,n=40,m=26,target=blink)
    G['nodes'][ey]['weights']=[0];C['eyeL' if sgn<0 else 'eyeR']=ey
    gl=uv_sphere('Catchlight_'+str(sgn),(.038,.054,.013),GLINT,parent=ep,t=(-.025,.105,.044),n=24,m=16)
    C['glintL' if sgn<0 else 'glintR']=gl

# Belly ribs: subtle, thin 3D curves hugging the lower white surface.
for i,x0 in enumerate([-.67,-.37,0,.37,.67]):
    ctr=[];ww=[];dd=[]
    for u in np.linspace(0,1,34):
        y=-.51-.50*u;x=x0*(1-.28*u)
        v=1-(x/(RX+.015))**2-(y/(RY+.015))**2
        if v<.006:break
        z=(RZ+.016)*sqrt(v)
        ctr.append((x,y,z));r=.0055*(sin(pi*u)**.6);ww.append(max(r,.001));dd.append(max(r*.65,.001))
    sweep('Belly_pleat_'+str(i),ctr,ww,dd,GROOVE,segments=8)

# Overlay geometry stays in the character coordinate system (no screen-space text).
listen=node('FX_Listen',body_root,t=(-1.19,.52,.30),s=(.0001,)*3,extras={'accessory':True});C['listen']=listen
for i,(a,b) in enumerate([((-.25,0,0),(-.43,.15,0)),((-.09,.17,0),(-.15,.39,0))]):
    tt=np.linspace(0,1,16);cs=[np.array(a)*(1-t)+np.array(b)*t for t in tt];rr=[.032*sin(pi*t)**.5+.001 for t in tt]
    sweep('Listen_ray_'+str(i),cs,rr,rr,SIGN,listen,16)

think=node('FX_Think',body_root,t=(1.09,1.00,.34),s=(.0001,)*3,extras={'accessory':True});C['think']=think
# Hand-built question mark curve, deliberately not a font glyph.
pts=[]
for t in np.linspace(0,1,35):
    a=pi*(.94-1.20*t);pts.append((.15*cos(a),.27+.15*sin(a),0))
start=np.array(pts[-1]);
for t in np.linspace(0,1,16)[1:]:pts.append(tuple(start*(1-t)+np.array([-.025,.025,0])*t))
rr=[.035]*len(pts);rr[0]=rr[-1]=.028
sweep('Question_curve',pts,rr,rr,SIGN,think,16)
uv_sphere('Question_dot',(.041,.041,.041),SIGN,think,t=(-.025,-.09,0),n=20,m=12)

success=node('FX_Success',body_root,t=(1.22,.61,.31),s=(.0001,)*3,extras={'accessory':True});C['success']=success
for i,(a,b) in enumerate([((0,.13,0),(.09,.38,0)),((.13,.055,0),(.33,.21,0))]):
    ts=np.linspace(0,1,16);cs=[np.array(a)*(1-t)+np.array(b)*t for t in ts];rs=[.034*sin(pi*t)**.55+.001 for t in ts]
    sweep('Success_ray_'+str(i),cs,rs,rs,SIGN,success,16)

error=node('FX_Error',body_root,s=(.0001,)*3,extras={'accessory':True});C['error']=error
# Sweating teardrop is attached to the left temple; no eyebrows and no mouth.
sweat=node('CTRL_Sweat',error,t=(-.79,.49,.71),q=align([0,0,1],[-.5,.3,.8]));C['sweat']=sweat
def sweatfn(v,u):
    a=2*pi*u;r=.105*(sin(pi*v)**.78)*(1.24-.85*v)
    return (r*cos(a),.29*v,.051/r if False else .54*r*sin(a))
grid_surface('Sweat_drop',sweatfn,CYAN,32,26,parent=sweat,reverse=True)
for i,(a,b) in enumerate([((1.10,.63,.32),(1.23,.84,.32)),((1.22,.48,.32),(1.46,.60,.32))]):
    ts=np.linspace(0,1,16);cs=[np.array(a)*(1-t)+np.array(b)*t for t in ts];rs=[.029*sin(pi*t)**.5+.001 for t in ts]
    sweep('Error_ray_'+str(i),cs,rs,rs,SIGN,error,16)

# Save rest transforms, then sample animation into standard TRS + morph glTF channels.
rest={i:{k:np.array(G['nodes'][i][k],float) for k in ('translation','rotation','scale')} for i in range(len(G['nodes']))}
ANIM_NODES=list(dict.fromkeys(C.values()))

def smooth(x):x=max(0,min(1,x));return x*x*(3-2*x)
def blink_pulse(t,c,width=.17):return max(0,1-abs(t-c)/width)
def pose(state,t,d):
    p={i:{k:vv.copy() for k,vv in rest[i].items()} for i in ANIM_NODES}
    w={C[key]:0. for key in ['eyeL','eyeR','finMeshL','finMeshR','finRimL','finRimR']}
    def rot(k,x=0,y=0,z=0):p[C[k]]['rotation']=np.array(qmul(rest[C[k]]['rotation'],euler(x,y,z)))
    def scl(k,v):p[C[k]]['scale']=np.array([v]*3)
    def move(k,v):p[C[k]]['translation']=rest[C[k]]['translation']+np.array(v)
    s=2*pi*t/max(d,1e-6)
    bob=.021*sin(s);rx=.010*sin(s);rz=.010*sin(s)
    fl=-.045*sin(s);fr=.045*sin(s);tl=.06*sin(s)
    eye_blink=max(blink_pulse(t,2.4),blink_pulse(t,5.1)) if state=='Idle_Loop' else 0
    w[C['eyeL']]=w[C['eyeR']]=eye_blink
    for k in ['listen','think','success','error']:scl(k,.0001)
    if state.startswith('Listen'):
        k=smooth(t/d) if state.endswith('Enter') else 1
        bob=.021*sin(s) if state.endswith('Loop') else 0
        rx=.095*k;rz=-.055*k;fl=-.13*k+.025*sin(s);fr=.04*k
        move('body',(0,bob,.07*k));scl('listen',.0001+k*.9999)
        b=blink_pulse(t,2.35) if state.endswith('Loop') else 0
        w[C['eyeL']]=w[C['eyeR']]=b
    elif state.startswith('Think'):
        k=smooth(t/d) if state.endswith('Enter') else 1
        rx=-.02*k;rz=.095*k
        fl=-.10;fr=.12
        # Near paddle rotates across the lower face instead of becoming an arm.
        rot('finL',0,0,-.03*k+.015*sin(s));rot('finR',0,0,.09)
        w[C['finMeshL']]=w[C['finRimL']]=k
        for key in ['eyePL','eyePR']:move(key,(.016*k,.047*k,0))
        scl('think',.0001+k*.9999);scl('listen',.0001)
        b=blink_pulse(t,2.6) if state.endswith('Loop') else 0
        w[C['eyeL']]=w[C['eyeR']]=b
    elif state=='Success':
        a=sin(pi*min(1,t/.65)) if t<.65 else 0
        # Return to neutral at end of one-shot. A small hand-like FIN wave, never a jump.
        k=smooth(t/.28)*(1-smooth((t-1.45)/.50))
        bob=.13*max(0,sin(pi*t/d));rz=-.06*k
        fr=.93*k+.08*sin(3*pi*t)*k;fl=-.12*k;tl=.18*k*sin(2*pi*t/d)
        w[C['eyeR']]=smooth((t-.34)/.16)*(1-smooth((t-1.11)/.18))
        scl('success',max(.0001,k));
    elif state.startswith('Error'):
        k=smooth(t/d) if state.endswith('Enter') else 1
        bob=-.035*k+.007*sin(s);rx=-.045*k;rz=-.024*k
        fl=-.74*k;fr=.73*k
        rot('finL',0,0,-.02*k);rot('finR',0,0,.02*k)
        for key in ['finMeshL','finMeshR','finRimL','finRimR']:w[C[key]]=k
        scl('error',.0001+k*.9999)
        if state.endswith('Hold'):
            b=blink_pulse(t,3.2);w[C['eyeL']]=w[C['eyeR']]=b
            move('sweat',(0,-.015*sin(s),0))
    if not state.startswith('Listen'):move('body',(0,bob,0))
    rot('body',rx,0,rz)
    if not (state.startswith('Think') or state.startswith('Error')):
        rot('finL',0,.012*sin(s),fl);rot('finR',0,-.012*sin(s),fr)
    rot('tail',.03*sin(s),tl,0)
    rot('dropL',.018*sin(s-.3),0,.035*sin(s-.25))
    rot('dropR',-.015*sin(s-.2),0,-.03*sin(s-.1))
    for key,eye in [('glintL','eyeL'),('glintR','eyeR')]:
        # Catchlight dissolves geometrically during a blink, no material animation.
        scl(key,max(.0001,1-w[C[eye]]*1.65))
    return p,w

clips=[('Idle_Loop',6.,True),('Listen_Enter',.48,False),('Listen_Loop',4.,True),('Think_Enter',.60,False),('Think_Loop',4.8,True),('Success',2.,False),('Error_Enter',.60,False),('Error_Hold',5.,True)]
clip_report=[]
for name,duration,loop in clips:
    # 30 fps samples keep asset animation deterministic on all players.
    times=np.linspace(0,duration,round(duration*30)+1)
    ti=accessor(times,'SCALAR');samplers=[];channels=[]
    poses=[pose(name,float(t),duration) for t in times]
    for ni in ANIM_NODES:
        for path,typ in [('translation','VEC3'),('rotation','VEC4'),('scale','VEC3')]:
            vals=np.array([p[0][ni][path] for p in poses])
            # All controllers have tracks so state blending restores previous-state transforms.
            if np.allclose(vals,vals[0],atol=1e-8):
                ii=accessor([0,duration],'SCALAR');vals=vals[[0,-1]]
            else:ii=ti
            out=accessor(vals,typ);si=len(samplers);samplers.append({'input':ii,'output':out,'interpolation':'LINEAR'});channels.append({'sampler':si,'target':{'node':ni,'path':path}})
    for ni in [C[key] for key in ['eyeL','eyeR','finMeshL','finMeshR','finRimL','finRimR']]:
        vals=np.array([p[1][ni] for p in poses]);si=len(samplers);samplers.append({'input':ti,'output':accessor(vals,'SCALAR'),'interpolation':'LINEAR'});channels.append({'sampler':si,'target':{'node':ni,'path':'weights'}})
    G['animations'].append({'name':name,'samplers':samplers,'channels':channels,'extras':{'loop':loop,'fps':30,'duration':duration}})
    clip_report.append({'name':name,'duration':duration,'loop':loop})
G['extras']={'boop':{'fiveStates':['idle','listen','think','success','error'],'units':'meters (arbitrary mascot scale)','front':'+Z','up':'+Y','controllerType':'hierarchical object pivots + eye and flipper morph targets','reference':'User-approved BOOP whale artwork; rear/side interpretation is original','clips':clip_report}}
G['buffers']=[{'byteLength':len(B)}]
j=json.dumps(G,ensure_ascii=False,separators=(',',':')).encode();j+=b' ' *((4-len(j)%4)%4);B+=b'\x00'*((4-len(B)%4)%4)
glb=struct.pack('<4sII',b'glTF',2,12+8+len(j)+8+len(B))+struct.pack('<I4s',len(j),b'JSON')+j+struct.pack('<I4s',len(B),b'BIN\x00')+B
(OUT/'boop.glb').write_bytes(glb)
report={'vertices':sum(v['vertices'] for v in mesh_stats),'triangles':sum(v['triangles'] for v in mesh_stats),'meshes':len(mesh_stats),'nodes':len(G['nodes']),'materials':len(G['materials']),'animations':clip_report,'bytes':len(glb),'meshBreakdown':mesh_stats,'limitations':['Procedural first 3D interpretation; not a pixel-identical sculpt of illustration.','Object-pivot rig with morph eyes and flippers, no skeleton-skin binding.','No textures, no normal maps, no external assets required.']}
(ROOT/'qa'/'asset-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='meshBreakdown'},ensure_ascii=False,indent=2))
