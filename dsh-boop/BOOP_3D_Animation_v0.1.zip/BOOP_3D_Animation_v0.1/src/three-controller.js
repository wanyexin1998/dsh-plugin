/* Optional adapter for an existing Three.js app.
 * Requires the host's installed `three`; not bundled into the offline preview.
 * This adapter is supplied as integration code and was NOT executed here because
 * this build environment has no Three.js package/network access.
 */
import { AnimationMixer, LoopOnce, LoopRepeat } from 'three';
const MAP = {
  idle: { loop: 'Idle_Loop', pose: 0 },
  listen: { enter: 'Listen_Enter', loop: 'Listen_Loop', pose: 0.45 },
  think: { enter: 'Think_Enter', loop: 'Think_Loop', pose: 0.75 },
  success: { enter: 'Success', pose: 0.75 },
  error: { enter: 'Error_Enter', loop: 'Error_Hold', pose: 0.5 },
};
export class BoopThreeController {
  constructor(gltf, { onStateChange = () => {}, reducedMotion = false } = {}) {
    if (!gltf?.scene || !Array.isArray(gltf.animations)) throw new TypeError('Pass GLTFLoader result.');
    this.root = gltf.scene; this.mixer = new AnimationMixer(this.root);
    this.actions = new Map(gltf.animations.map(c => [c.name, this.mixer.clipAction(c)]));
    for (const cfg of Object.values(MAP)) for (const name of [cfg.enter, cfg.loop].filter(Boolean)) {
      if (!this.actions.has(name)) throw new Error(`Missing BOOP animation: ${name}`);
    }
    this.onStateChange = onStateChange; this.reducedMotion = reducedMotion;
    this.active = true; this.disposed = false; this.state = 'idle';
    this.finished = event => {
      if (event.action !== this.current || this.reducedMotion || this.disposed) return;
      const cfg = MAP[this.state];
      if (this.state === 'success') this.setState('idle');
      else if (cfg.loop) this._play(cfg.loop, true, 0.15);
    };
    this.mixer.addEventListener('finished', this.finished);
    this.setState('idle');
  }
  _play(name, loop, fade = 0.30) {
    const next = this.actions.get(name), previous = this.current;
    next.reset().setLoop(loop ? LoopRepeat : LoopOnce, loop ? Infinity : 1);
    next.clampWhenFinished = !loop;
    next.enabled = true; next.paused = false; next.setEffectiveTimeScale(1).setEffectiveWeight(1).play();
    if (previous && previous !== next) next.crossFadeFrom(previous, fade, false);
    this.current = next;
  }
  setState(state) {
    if (!MAP[state]) throw new RangeError(`Unknown BOOP state: ${state}`);
    if (this.disposed) return;
    this.state = state; const cfg = MAP[state];
    if (this.reducedMotion) {
      this.mixer.stopAllAction(); this._play(cfg.loop || cfg.enter, Boolean(cfg.loop), 0);
      this.current.time = cfg.pose; this.current.paused = true; this.mixer.update(0);
    } else this._play(cfg.enter || cfg.loop, !cfg.enter);
    this.onStateChange(state);
  }
  setReducedMotion(value) { this.reducedMotion = Boolean(value); this.setState(this.state); }
  setActive(value) { this.active = Boolean(value); }
  setAccessories(value) {
    this.root.traverse(o => { if (o.userData?.accessory) o.visible = Boolean(value); });
  }
  update(deltaSeconds) {
    if (!this.disposed && this.active && !this.reducedMotion) this.mixer.update(Math.min(Math.max(deltaSeconds, 0), 0.1));
  }
  dispose() {
    if (this.disposed) return; this.disposed = true;
    this.mixer.removeEventListener('finished', this.finished);
    this.mixer.stopAllAction(); this.mixer.uncacheRoot(this.root);
    // Host owns geometry/material disposal; do not dispose shared GLTF resources here.
  }
}
