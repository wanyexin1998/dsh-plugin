# 前端审查收尾核对

固定范围：`6f9c046681e58a1304704baf165dce5de2a49f4f..b92fa37ed67182916e133e5e60b4b970a858d5e8`。

## 覆盖计数

精确 `git diff --name-only` 共 **62 文件**。frontend 清单 20 + persistence 报告表格 16 + runtime 清单 7 = **43 个互不重叠的变更文件**；没有分配到 diff 外的路径。差集正好 19，若主审记录覆盖下列 19 文件，则 62 文件没有遗漏。这里确认的是清单集合，不替主审声明其每项阅读/运行过程。

```text
dsh-boop/docs/refactor/boop-mvp-v0.2/ADR-0001-boop-home.md
dsh-boop/docs/refactor/boop-mvp-v0.2/RUN.md
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/acceptance.json
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/baseline.json
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/implementation-ledger.md
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/screenshots/boop-home-narrow.png
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/screenshots/boop-home-settings.png
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/screenshots/boop-home-welcome-light.png
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/screenshots/boop-home-working-dark.png
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/screenshots/dsh-web-boop-ready.png
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/screenshots/dsh-web-boop.png
dsh-boop/docs/refactor/boop-mvp-v0.2/evidence/screenshots/dsh-web-shell.png
dsh-boop/package.json
dsh-boop/presets/boop.patch.yml
dsh-boop/tests/helpers/test-host.mjs
dsh-boop/tools/build-test-payload.mjs
dsh-boop/tools/desktop-gui-probe.mjs
dsh-boop/tools/inspect-asar.mjs
dsh-boop/tools/rehearse-install.mjs
```

## FE-07：保留 P2，建议以确定的焦点丢失为标题

- `home/index.tsx:19` 定义 `workButton`，唯一其他引用为 `57` 的 `workButton.current?.focus()`；从未绑定 JSX `ref` 或传到 Header，必为 null。
- `WorkDrawer.tsx:23–26` 主动聚焦关闭按钮，关闭后按钮卸载；没有相应恢复机制。SettingsPanel 同样只有进入聚焦。
- 全新入口、Header、抽屉/controller 没有 Escape handler。旧 `taskboard/index.tsx` 和 `control.tsx` 的焦点/Escape 实现没有被新主页引入，不能作为反证。
- 保留“键盘关闭工作抽屉后无法回到触发按钮”的 P2。窄屏焦点穿透是源码支持的附加问题，但未做真实键盘走查，勿写成实机已测。桌面普通 aside 不必强制 focus trap，本项不应要求所有桌面抽屉都模态化。

## FE-09：保留 P2，限定为错误的页面意图恢复

- `src/client/index.tsx:98` 只把 `boop.home.intent` 写成 `1`，`144` 加载时据此无条件请求 `selectPanel('boop.home')`。
- 全 `src/client` 搜索没有清除此 key，也没有订阅 `layout.panelInfo/activePanelId` 令当前普通会话覆盖 BOOP 意图；`controller.destroy` 也不处理。
- 因而“进过一次 BOOP → 之后用户选择普通 DSH → 刷新/插件重载”会再次请求切回 BOOP，不是恢复用户最后选择的页面。没有发现宿主拥有/自动清理此私有 key 的依据。
- 保留 P2，表述为“普通会话刷新被 BOOP 恢复逻辑抢占/要求切回”，不声称草稿/对话数据被删除，也不把 tab 关闭后 sessionStorage 清理当作同一浏览器页内的修复。

## 追加 PERSIST-5 的关键反证

`reference-guard.ts:84–87` 的确构造缺少 id/role 的消息；正式 `snapshotSessionEvent` 会报 `lacks an identified message`。但据此推导 **Session.append 当场拒绝** 不成立。

我用安装的正式 rc.2 `Session.create`，将 `gateHomeReferences` 输出（合法原 user + 不完整 notice）逐一调用真实 `append('user/message', message, {surfaceOp:'append'})`，结果：

```json
[
  {"index":0,"append":"accepted","snapshot":"accepted"},
  {"index":1,"append":"accepted","snapshot":"session event at seq 1 lacks an identified message"}
]
```

实际 `append` 只经过 `validateSessionEventData` 与 `surfaceManager.validateNext/planSurfaceEvent`，没有调用完整 `assertMessageEventShape`；后者由 `snapshotSessionEvent/adoptSessionEvent` 使用。

**裁定 REVISE**：通知协议不合法和正式快照边界失败可证；“任何被拒引用都会在 append 阶段令本轮聊天异常”的新增 P1 应撤回。未验证后续模型 serializer，不能以本次证据宣称每次即时聊天失败。PERSIST-3 保持“原生 readSurface 已触发”，不扩展为真实模型已收到秘密/发生外传。

没有重复运行大测试，没有修改产品代码。
