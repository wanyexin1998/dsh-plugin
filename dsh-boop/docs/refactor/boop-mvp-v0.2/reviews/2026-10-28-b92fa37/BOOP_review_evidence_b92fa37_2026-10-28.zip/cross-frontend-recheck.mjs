import assert from 'node:assert/strict'
import fs from 'node:fs'
import vm from 'node:vm'
import { HomeController } from './repo/dsh-boop/src/client/home/controller.ts'
import { readWorkChoice } from './repo/dsh-boop/src/client/home/read-work-choice.ts'
import { mainSessionStatusLine } from './repo/dsh-boop/src/client/main-session.ts'

const root = new URL('./repo/dsh-boop/', import.meta.url)
const results = []
let remoteTasks = []
let connection = 'connected'
let listener
let reads = 0
const home = {state:'ready',mainSessionId:'home',bindingVersion:1,capabilities:{send:true,readSources:true,delegate:true,stop:true,reasonCodes:[]}}
const controller = new HomeController({
  async call(endpoint) {
    if (endpoint === 'boop/ensureHome') return {data:home}
    if (endpoint === 'boopTasks/listV2') { reads++; return {data:{items:remoteTasks}} }
  },
  retain() { return {id:'home',native:{},ready:Promise.resolve(),release(){}} },
  connection:{getSnapshot:()=>connection,subscribe(fn){listener=fn;return()=>{}},reconnect(){}},
  selectPanel(){},openSource(){},async insertReference(){return true},async setDraftText(){return true}
})
await controller.mount()
remoteTasks = [{taskId:'new',title:'new delegated task',productState:'running'}]
controller.setDrawer('work')
connection='disconnected';listener()
connection='connected';listener()
await new Promise(resolve=>setImmediate(resolve))
assert.equal(reads,1)
assert.deepEqual(controller.getSnapshot().tasks,[])
await controller.refreshTasks()
assert.equal(controller.getSnapshot().tasks[0].taskId,'new')
results.push({id:'FE-01',result:'CONFIRMED',observation:'New remote work remains absent after opening Work and disconnect/reconnect; explicit internal refresh sees it.'})
controller.destroy()

const choiceValue={schemaVersion:2,kind:'boop.catalog',ok:true,data:{mode:'work',originUserMessageId:'u1',sourceSeq:4,candidates:[{sessionId:'old-target',title:'Old candidate',mention:'@[Old candidate](dsh-session:Im9sZC10YXJnZXQi)',selectionKey:'k1'}]}}
const choiceNode={kind:'tool-result',name:'boop_catalog',call:{id:'c1'},content:[{type:'text',text:JSON.stringify(choiceValue)}],seq:5}
const laterUser={kind:'user',id:'u2',seq:6,content:[{type:'text',text:'Cancel that; discuss another project instead.'}]}
assert.equal(readWorkChoice([choiceNode,laterUser])?.candidates[0].sessionId,'old-target')
results.push({id:'FE-04',result:'CONFIRMED',observation:'A later direct user message leaves the previous catalog candidates actionable after input phase returns to plain.'})

// Load the actual generated BOOP bundle, replacing only the rendering shell.
const hooks=[]
const React={createContext(){return{Provider:'Provider'}},createElement(type,props,...children){return{type,props:{...props,children}}},useEffect(fn){hooks.push(fn)}}
const registrations=[]
let definition
const document={createElement(){return{setAttribute(){},remove(){}}},head:{appendChild(){}}}
const context={window:{__ModuleLoader__:{load(value){definition=value}}},document,console,AbortController,sessionStorage:{getItem(){return null},setItem(){}}}
vm.runInNewContext(fs.readFileSync(new URL('lib/client.js',root),'utf8'),context)
const jsx=(type,props)=>({type,props})
const plugin=definition.factory(name=>{if(name==='react')return React;if(name==='react/jsx-runtime')return{jsx,jsxs:jsx,Fragment:'Fragment'};throw new Error(`Unexpected module ${name}`)})

// Execute the exact native insertReference method from the installed rc.2 bundle.
const nativePath=new URL('node_modules/.pnpm/@deepseek-ai+dsh-client-ui-conversation@0.2.1-rc.2_@deepseek-ai+cordis@4.0.5/node_modules/@deepseek-ai/dsh-client-ui-conversation/lib/client.js',root)
const nativeBundle=fs.readFileSync(nativePath,'utf8')
const nativeMethod=nativeBundle.match(/\n\t\t\tinsertReference\(ref, span\) \{[\s\S]*?\n\t\t\t\}/)?.[0]
assert.ok(nativeMethod)
const insertReference=vm.runInNewContext(`({${nativeMethod}}).insertReference`)
let nativeInsertions=0
let draft='Please inspect only. Do not deploy. @[Selected](dsh-session:InMi)'
const facade={core:{state:{phase:'plain'}},rev:9,projection:{detectText:draft},draftEditor:{insertReference(){nativeInsertions++;return true}},insertReference,actions:{captureInsertion(){return{start:draft.length,end:draft.length,draftRev:9}}},setDraft(text){draft=text}}
const ctx={
  effect(fn){fn()},
  slots:{inject(name,fn){return fn()},register(options,component){registrations.push({options,component});return()=>{}}},
  layout:{selectPanel(){}},
  connection:{state:{getSnapshot:()=> 'connected',subscribe:()=>()=>{}},rpc:{async call(_channel,endpoint){return endpoint==='boop/ensureHome'?{data:home}:{data:{items:[]}}}}},
  sessions:{scope(){return{}},retain(){return{ready:Promise.resolve(),release(){}}}},
  conversation:{input:{for(){return facade}}},uiWorkspace:{openSession(){}}
}
plugin.apply(ctx)
const Panel=registrations.find(x=>x.options.name==='main').component
const panel=Panel({})
const actualController=panel.props.controller
const cleanup=hooks[0]()
await new Promise(resolve=>setImmediate(resolve))
assert.equal(await actualController.insertCandidate('@[Target](dsh-session:InQi)','Target'),false)
assert.equal(nativeInsertions,0)
assert.equal(facade.insertReference({},facade.actions.captureInsertion()),true)
assert.equal(nativeInsertions,1)
results.push({id:'FE-02',result:'CONFIRMED',observation:'Real BOOP adapter sends a span without draftRev; exact installed DSH insertReference method rejects it. The valid native actions capture is accepted.'})

assert.equal(await actualController.continueTask({title:'Inspect UI'}),true)
assert.equal(draft,'继续处理「Inspect UI」。还要补充：')
assert.equal(draft.includes('Do not deploy'),false)
results.push({id:'FE-03',result:'CONFIRMED',observation:'Real BOOP Continue callback selects destructive native setDraft; the existing restriction and target reference are replaced.'})

const observer=registrations.find(x=>x.options.name==='sidebar.footer.action').options.inject().observer
assert.equal(observer.getSnapshot().phase,'ready')
assert.equal(mainSessionStatusLine(observer.getSnapshot()).text,'数据域不可用')
results.push({id:'FE-08',result:'CONFIRMED',observation:'Ready home leaves the reused identity store.host null, so the sidebar still reports data-domain unavailable.'})
cleanup?.()
fs.writeFileSync(new URL('./cross-runtime-frontend-results.json',import.meta.url),JSON.stringify({scope:'isolated frontend/control and native method validation; not a DSH browser integration run',results},null,2)+'\n')
console.log(JSON.stringify(results,null,2))
