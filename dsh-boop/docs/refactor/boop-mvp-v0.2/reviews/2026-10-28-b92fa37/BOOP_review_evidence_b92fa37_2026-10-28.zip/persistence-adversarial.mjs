import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { BoopDatabase as V1Database } from './baseline/dsh-boop/src/host/persistence/database.ts';
import { BoopRepository as V1Repository } from './baseline/dsh-boop/src/host/persistence/repository.ts';
import { BoopStorage } from './repo/dsh-boop/src/host/persistence/storage.ts';
import { BoopDatabase } from './repo/dsh-boop/src/host/persistence/database.ts';
import { BoopRepository } from './repo/dsh-boop/src/host/persistence/repository.ts';
import { HomeService } from './repo/dsh-boop/src/host/home/service.ts';
import { createDelegationPorts } from './repo/dsh-boop/src/host/home/native-session.ts';
import { DelegationService } from './repo/dsh-boop/src/host/delegation/service.ts';
import { gateHomeReferences } from './repo/dsh-boop/src/host/home/reference-guard.ts';
import { encodeSessionReferenceUri, formatSessionReferenceMention } from './repo/dsh-boop/src/shared/session-mention.ts';
import { apply as applyHost } from './repo/dsh-boop/src/host/index.ts';

const findings = [];
const nativeModuleRoot = path.resolve('repo/dsh-boop/node_modules/.pnpm');
const nativeReferenceDir = fs.readdirSync(nativeModuleRoot).find(x => x.startsWith('@deepseek-ai+dsh-session-reference@'));
const official = await import(pathToFileURL(path.join(nativeModuleRoot, nativeReferenceDir, 'node_modules/@deepseek-ai/dsh-session-reference/lib/index.js')).href);
const nativeSessionDir = fs.readdirSync(nativeModuleRoot).find(x => x.startsWith('@deepseek-ai+dsh-session@'));
const officialSession = await import(pathToFileURL(path.join(nativeModuleRoot, nativeSessionDir, 'node_modules/@deepseek-ai/dsh-session/lib/index.js')).href);

function homeFixture(dshHome) {
  const sessions = new Map();
  const guards = [];
  return {
    sessions, guards,
    native: {
      async observe(id) { return { exists: sessions.has(id), subagent: false, archived: false, preset: 'boop', cwd: path.join(dshHome, 'boop', 'home') }; },
      async resolve(id) { return { ok: sessions.has(id), agent: sessions.get(id) ?? null }; },
      async create(input) { sessions.set(input.sessionId, { session: { id: input.sessionId }, ctx: { on(...args) { guards.push(args); } } }); return { sessionId: input.sessionId }; },
      async flush() { return true; },
      async modelAvailable() { return true; },
    },
  };
}

// Real schema-1 creation, real schema-2 migration, and the production HomeService.
{
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'boop-review-legacy-'));
  fs.mkdirSync(path.join(dir, 'boop'), { recursive: true });
  const old = new V1Database({ path: path.join(dir, 'boop', 'boop.sqlite'), fts: false });
  old.bootstrap();
  const scopeId = (await import('./repo/dsh-boop/src/host/persistence/storage.ts')).deriveScopeIdentity(dir).scopeId;
  const oldRepo = new V1Repository(old);
  oldRepo.ensureScope(scopeId, 'dsh-local-owner');
  oldRepo.bindMainSession(scopeId, 'boop-main');
  old.close();
  const storage = new BoopStorage({ dshHome: dir });
  assert.equal(storage.start().ok, true);
  assert.equal(storage.db.schemaVersion(), 2);
  const fixture = homeFixture(dir);
  const service = new HomeService({ db: storage.db, scopeId, ownerId: 'dsh-local-owner', dshHome: dir, native: fixture.native, policy: { decide: () => 'allow' } });
  const result = await service.ensureHome();
  assert.equal(result.ok, true);
  assert.equal(result.data.state, 'ready');
  const currentScope = storage.repo.getScope(scopeId).mainSessionId;
  const history = storage.db.db.prepare('SELECT session_id FROM home_binding_history WHERE closed_at IS NULL').get().session_id;
  assert.equal(currentScope, 'boop-main');
  assert.notEqual(history, currentScope);
  assert.equal(result.data.mainSessionId, history);
  findings.push({ id: 'PERSIST-1', reproduced: true, result: 'ready', legacyScopeMain: currentScope, homeHistoryMain: history, created: fixture.sessions.size });
  storage.close();
  fs.rmSync(dir, { recursive: true, force: true });
}

// Real existing exclusion rows are ignored by the production ports and policy.
{
  const db = new BoopDatabase({ path: ':memory:', wal: false });
  db.bootstrap();
  const repo = new BoopRepository(db, () => '2026-10-28T00:00:00Z', () => 'forget-rule-1');
  repo.ensureScope('scope', 'owner');
  repo.saveForgetRule({ scopeId: 'scope', sourceFingerprint: 'secret-session', selector: { sessionId: 'secret-session' }, mode: 'exclude_source' });
  repo.upsertCursor({ scopeId: 'scope', sessionId: 'secret-session', sourceGeneration: 'generation', throughSeq: 0, state: 'excluded' });
  const ports = createDelegationPorts({}, 'scope', () => '2026-10-28T00:00:00Z');
  const delegation = new DelegationService(db, 'scope', ports);
  delegation.inheritAccess('owner', 'host-local-owner');
  assert.equal(repo.forgetRules('scope').length, 1);
  assert.equal(delegation.canRead('secret-session', null), 'allow');
  const mention = formatSessionReferenceMention({ sessionId: 'secret-session', label: 'Secret' });
  const guarded = gateHomeReferences([{ source: { kind: 'user' }, content: [{ type: 'text', text: mention }] }], { decide: (id) => delegation.canRead(id, null) });
  const remaining = official.parseSessionReferenceText(guarded[0].content[0].text).references;
  assert.equal(remaining[0].sessionId, 'secret-session');
  findings.push({ id: 'PERSIST-2', reproduced: true, forgetRuleCount: 1, sourceCursorState: 'excluded', canRead: 'allow', nativeReferenceStillReads: remaining.map(r => r.sessionId) });
  db.close();
}

// A denied outer mention can leave a fresh canonical URI in its visible label.
{
  const inner = encodeSessionReferenceUri('secret-session');
  const attack = formatSessionReferenceMention({ sessionId: 'blocked-outer', label: inner });
  const guarded = gateHomeReferences([{ id: 'user-message', source: { kind: 'user' }, content: [{ type: 'text', text: attack }] }], { decide: () => 'deny' });
  const parsedByNative = official.parseSessionReferenceText(guarded[0].content[0].text);
  assert.equal(parsedByNative.references[0].sessionId, 'secret-session');
  const consumed = [];
  await official.SessionReferenceResolver.prototype.prepareDirectMessages.call({ async prepare(_agent, content, references) { consumed.push(...references); return { content, additionalContext: { id: 'reference-context', source: { kind: 'session-reference' }, content: [{ type: 'text', text: 'synthetic read evidence' }] } }; } }, {}, guarded);
  assert.equal(consumed[0].sessionId, 'secret-session');
  findings.push({ id: 'PERSIST-3', reproduced: true, policy: 'deny all', input: attack, guardOutput: guarded[0].content[0].text, nativeResolverConsumed: consumed.map(r => r.sessionId) });
}

// The official Session append accepts the guard's incomplete notice, while the
// official snapshot boundary rejects it. Do not infer immediate turn failure
// from snapshot validation alone. Keep a valid user-message control in this case.
{
  const userMessage = { id: 'human-message', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: formatSessionReferenceMention({ sessionId: 'blocked', label: 'Blocked' }) }] };
  const guarded = gateHomeReferences([userMessage], { decide: () => 'deny' });
  const session = officialSession.Session.create('guard-notice-validation');
  const originalEvent = session.append('user/message', guarded[0], { surfaceOp: 'append' });
  assert.doesNotThrow(() => officialSession.snapshotSessionEvent(originalEvent));
  let noticeEvent;
  assert.doesNotThrow(() => { noticeEvent = session.append('user/message', guarded[1], { surfaceOp: 'append' }); });
  let snapshotError;
  assert.throws(() => officialSession.snapshotSessionEvent(noticeEvent), (error) => {
    snapshotError = error.message;
    return /lacks an identified message/.test(error.message);
  });
  findings.push({ id: 'PERSIST-5', reproduced: true, guardNoticeHasId: 'id' in guarded[1], guardNoticeHasRole: 'role' in guarded[1], originalAppendAccepted: true, originalSnapshotAccepted: true, appendAccepted: true, snapshotError, immediateChatFailure: 'not established by this probe' });
}

// Exercise actual apply() wiring: fence is lost after startup, but ensureHome
// still creates and binds because the production constructor omits fenceOk.
{
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'boop-review-fence-'));
  const sessions = new Map();
  const cleanup = [];
  let creates = 0;
  const ctx = {
    logger: { info() {}, warn() {} },
    dshHomePath: () => dir,
    provide(name, value) { this[name] = value; },
    effect(factory) { cleanup.push(factory()); },
    reflect: { get(name) { if (name === 'sessionProjections') return { stateOf() { return 'boop'; } }; return null; } },
    sessionController: {
      async create(input) { creates++; sessions.set(input.sessionId, { id: input.sessionId, header: { cwd: input.cwd }, ctx: { on() {} } }); return { sessionId: input.sessionId }; },
      async resolveAgent(id) { const session = sessions.get(id); return session ? { session, ctx: session.ctx } : null; },
    },
    sessions: { get(id) { return sessions.get(id); }, async flush() { return true; } },
  };
  applyHost(ctx);
  assert.ok(ctx.boop);
  const storage = ctx.boop.storage();
  storage.db.db.prepare('UPDATE runtime_lease SET holder = ?, fencing_token = fencing_token + 1, expires_at = ? WHERE scope_id = ?').run('successor', String(Date.now() + 60000), storage.identity.scopeId);
  assert.equal(storage.checkWrite().ok, false);
  const result = await ctx.boop.ensureHome();
  assert.equal(result.ok, true);
  assert.equal(result.data.state, 'ready');
  assert.equal(creates, 1);
  findings.push({ id: 'PERSIST-4', reproduced: true, checkWrite: storage.checkWrite(), nativeCreatesAfterFenceLost: creates, resultState: result.data.state });
  for (const f of cleanup) if (typeof f === 'function') f();
  fs.rmSync(dir, { recursive: true, force: true });
}

fs.writeFileSync('persistence-adversarial-results.json', JSON.stringify({ head: 'b92fa37ed67182916e133e5e60b4b970a858d5e8', runtime: process.version, findings }, null, 2) + '\n');
console.log(JSON.stringify(findings, null, 2));
