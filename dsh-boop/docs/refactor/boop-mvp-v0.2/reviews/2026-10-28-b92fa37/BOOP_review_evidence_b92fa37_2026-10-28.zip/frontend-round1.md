# BOOP 前端第一轮对抗性审查

- 仓库：`wanyexin1998/dsh-plugin`
- Base：`6f9c046681e58a1304704baf165dce5de2a49f4f`
- Head：`b92fa37ed67182916e133e5e60b4b970a858d5e8`
- 审查范围：20 个变更文件，见 `frontend-coverage.json`。
- 方法：精确 diff、沿调用链阅读、安装的 DSH `0.2.1-rc.2` 原生实现与契约交叉核验、5 个隔离定向复现。没有修改产品代码，没有访问网络，没有声称真实浏览器/模型联调通过。
- 可复现：在本目录运行 `node frontend-validation.mjs`；结果 `frontend-validation.json`。脚本加载本分支实际构建的 `lib/client.js` 并对候选插入执行安装宿主 bundle 的原始 `insertReference` 方法，渲染层/远端数据使用隔离替身。

## 可报告问题

### FE-01 · P1 · 工作状态在打开首页后不再同步，主流程产生的任务和待确认结果无法出现

**位置**：`dsh-boop/src/client/home/controller.ts:91–93, 132, 145–153, 155–157`；消费位置 `home/BoopSession.tsx:65–69`、`home/index.tsx:49, 57`。

**触发**：首次打开 BOOP 时列表为空，随后通过正常主聊天工具委托工作；或者打开时任务 running，后台完成；或者另一个窗口改变状态后本窗口断线再恢复。

**实际**：唯一常规读取在 `mount()` 尾部。其他调用仅来自 stop/confirm/reconcile 后。连接回调只改 connection，工作按钮只改 drawer；没有订阅任务变化、native 聊天变化、轮询或重新打开抽屉时同步。因此新委托完全不出现在卡片/抽屉，旧任务的“停止”也不会变成“确认收下”，通常只能离开再回来。消息区即使收到文字回执，也不能使另一份 controller.tasks 状态更新。

**验证**：隔离数据源初始空 → mount → 数据源新增真实形状任务 → 打开工作抽屉 → disconnect/reconnect，读取次数仍为 1、可见 tasks 仍空；手动调用未暴露 UI 的 `refreshTasks()` 后立刻读到任务。全源码搜索没有其他刷新调用/事件桥。

**修复/验收**：增加生命周期管理的订阅或低频同步，重连刷新且不重建 retained Session；任务变化应在同一页面可见，主聊天草稿不丢。后台完成、跨窗口确认、断线恢复分别验收。

### FE-02 · P1 · 候选会话点击必然无法插入原生引用

**位置**：`dsh-boop/src/client/index.tsx:65–77`，尤其 `70`。

**原因**：`captureInsertion()` 是宿主注入的 `inputActions` / `SessionInputShell.actions` 方法，不是 `SessionInput` facade 顶层方法。此处取 `facade.captureInsertion?.()` 得到 undefined，回退 `{start:0,end:0}`。传给原生 `insertReference` 的 span 缺少 `draftRev`。

**宿主证据**：安装的 `@deepseek-ai/dsh-client-ui-conversation@0.2.1-rc.2/lib/types/client/contract/input.d.ts` 将它定义在 `InputActions`；实际 `lib/client.js:14913–14916` 实现在 `actions`；`15309–15314` 的 `insertReference` 在 `span.draftRev !== this.rev` 时直接 false。

**触发/后果**：用户在候选卡点击任意会话，总提示“没有放进输入框，请再试一次”；重试仍失败，歧义目标选择闭环断开。

**验证**：实际 BOOP 构建 bundle 接真实宿主原方法，native counter 为 0，返回 false；对照使用原生 `actions.captureInsertion()` 的 revision span 返回 true、counter 为 1。不是单纯根据文档推测。

**修复/验收**：把实际 Session scope 注入的 `inputActions` 接入动作，捕获 revision/caret 后只插入、不替换已选正文，成功后 focus；验证非空草稿、选区、附件、输入期间 revision 变更与普通/失败状态。

### FE-03 · P1 · “继续处理”覆盖已有草稿和目标引用，会删掉用户尚未发送的限制

**位置**：`dsh-boop/src/client/home/controller.ts:175–177` → `dsh-boop/src/client/index.tsx:82–89`。

**触发**：输入框已有“只检查，不要部署”等草稿或引用 chip，点击某工作卡的“继续处理”。

**实际**：无条件调用原生 `facade.setDraft(text)`。该 API 的契约与实现都明确替换整个草稿、去掉已有 inline references，并非追加。新的文本只有任务自然标题与“还要补充”，没有准确 task/session 引用。用户原约束在下一次发送前就被清除。

**验证**：实际构建 bundle 的 continue callback，输入草稿含 `Do not deploy` 和 canonical session mention，点击后只剩 `继续处理「Inspect UI」。还要补充：`。真实宿主契约确认 `setDraft` 的替换语义（`contract/input.d.ts`，`lib/client.js:15008–15013`）。该隔离测试不声称已运行真实 Lexical 浏览器。

**修复/验收**：使用 `inputActions.captureInsertion/insertText` 或原生 reference 插入，保存现有 draft、chips、附件；传准确任务/目标上下文；不自动 submit。验证已有草稿、输入法组合、选区、发送中锁定与多同名任务。

### FE-04 · P2 · 旧候选不会被后续用户消息撤销，选完再删除也不能重新选择

**位置**：`dsh-boop/src/client/home/read-work-choice.ts:29–55`；`TargetCandidates.tsx:15, 21, 27`；`BoopSession.tsx:43, 61`。

**触发/后果**：catalog 返回候选后，用户发送“改成另一个项目/不用了”；下一轮输入 phase 回 plain，函数继续往历史回溯并返回旧 catalog，没有用 originUserMessageId/sourceSeq 或后续 user 节点作废，旧卡重新可操作。另一个状态问题是 inserted 只存单个 selectionKey，从未订阅草稿 occurrences；用户删除已经选入的引用后，那个选项仍被 disabled，直到重新挂载。

**验证**：向 `readWorkChoice` 传真实形状 tool-result 后跟 seq 更大的 user 节点，仍返回旧目标。此问题本身不会自动派工；用户仍需发送，故不夸大为自动授权绕过。

**修复/验收**：后续 user 节点/新提交令旧卡失效，失败提交保留原生草稿但不恢复过时卡；根据同一草稿中的实际引用判断是否禁重复选择。

### FE-05 · P2 · “查看详情”没有详情，交付物和检查失败证据在 BOOP 页面不可见

**位置**：`dsh-boop/src/client/home/index.tsx:20–26`；`BoopSession.tsx:89–95`；`WorkCard.tsx:24–39`。

**触发**：用户点有结果工作卡的“查看详情”，尤其在抽屉中点击。

**实际**：view 动作仅 `setDrawer('work')`，不记录选中 task、不调用已实现的 `boopTasks/detailV2`、不显示详情。抽屉内再次点击没有可见变化。WorkCard 只展示自然状态、summary、missing；全 home 产品代码没有渲染 artifacts、evidence、verification checks/summary 或不可变历史结果。因此即使后端返回检查 failed，用户仍只看到“已交付，可以查看结果”和确认按钮，要自己去原会话翻找。

**证据**：完整调用链与全 `src/client/home` 字段引用搜索；preview 的 verification 字段只是样例数据，没有真实渲染代码。没有将静态判断说成浏览器已复现。

**修复/验收**：明确 task 详情状态并读取/呈现版本、产物链接、真实检查结论、证据、缺项；“确认收下”与“检查是否通过”并列，确认不抹除失败事实。点击详情应产生可观察变化。

### FE-06 · P2 · 网络/版本冲突造成停止或确认失败时，页面无反馈并可能清空最后事实

**位置**：`dsh-boop/src/client/home/controller.ts:148–152, 185–206`；`dsh-boop/src/client/index.tsx:30–35`。

**触发**：任务版本被另一窗口更新、停止 RPC 失败、或 RPC 后读取失败；也可在 `connecting`/unknown 阶段点击。

**实际**：call 已把异常转为 `{ok:false,error}`，stop/confirm 完全不看回复就 refresh；refresh 遇错误 response 把 items 设为空。页面既没有提示请求失败/不确定，也可能把仍在执行的任务卡移除。只在恰好 connection===disconnected 的 stop 前置分支显示提示，不能覆盖连接过程中/远端拒绝的真实失败。

**状态**：代码路径确认，尚未单独写故障复现；可由主审决定是否独立报告或并入 FE-01 状态同步缺陷。

**修复/验收**：区分读取错误与空列表，保留最后快照；检查 carrier envelope 与业务 ok，展示自然错误/下一步；不把发送结果未知当成功，不盲目重发。

### FE-07 · P2 · 抽屉关闭无法恢复触发按钮焦点；窄屏覆盖层没有 Escape/焦点边界

**位置**：`dsh-boop/src/client/home/index.tsx:19, 45–57`；`Header.tsx:4–23`；`WorkDrawer.tsx:23–32`；`SettingsPanel.tsx:9–19`。

**证据**：workButton ref 创建后没有赋给任何 JSX/button，也没有传给 Header；关闭时 `workButton.current?.focus()` 永远为空。抽屉挂载聚焦关闭按钮，卸载后焦点无归属。没有 Escape listener 或窄屏 sheet 的焦点约束，覆盖时 Tab 可进入被遮挡的聊天控件。

**状态**：静态路径确认，没有实机键盘复现。P2 候选，可在综合报告附录列出；不是安全漏洞。

### FE-08 · P2 · 首页已 ready，侧栏仍永久报“数据域不可用”

**位置**：`dsh-boop/src/client/index.tsx:38, 123–125, 158`；未改的被调用函数 `src/client/main-session.ts:402–408`；`header.tsx:47, 84–87`。

**原因**：复用 v1 mainStore/状态文案，但 v2 初始化只写 mainSessionId 和 phase，没有写 host。`mainSessionStatusLine` 在 phase ready、host null 时返回“数据域不可用”；这是必现的假警告，设置页也一直称“未持久绑定”。

**验证**：实际 BOOP bundle 完成 ready 后读取注入 sidebar observer，phase ready、host null，真实 status 函数返回“数据域不可用”。仓库提交的 `dsh-web-boop-ready.png` 左下角也能看到这个文案。

**修复/验收**：首页与固定入口共用新的 HomeView 投影，不伪造旧 host facts；正常 ready 不显示故障，真实 unavailable/repair 才显示准确说明。

### FE-09 · P2 候选 · 访问过一次 BOOP 后，从普通 DSH 刷新也被强制带回 BOOP

**位置**：`dsh-boop/src/client/index.tsx:97–99, 143–145`。

**证据**：openHome 永久写 sessionStorage intent='1'，全 client 没有清除该 key 或根据 layout.activePanelId 更新它的代码。此后即使用户主动去普通会话，刷新/插件重载仍自动 selectPanel(boop.home)。计划要求的是保留“当前”页面归属。

**状态**：静态路径确认；无需声称旧记录被篡改。可作 P2 普通 DSH 隔离回归，优先级低于核心闭环。

## 反证与保留意见

- SessionProvider 的声明子槽 + 注入方式正确；没有发现 import 不存在 InputBar/Provider 的问题。
- conversation.content 局部 views override 仍调用 native conversation.session，故没有因自造 textarea 直接替换正式输入；preview.tsx 中的 Composer 是单独演示文件，未被产品入口引用。
- stylesheet 规则实际以 `[data-boop-home]` 为边界，没有直接全局改 body；body dark 属性仅作匹配，没有写宿主主题。原生 approval dock/overlay 没有被本地 CSS selector 隐藏，不能仅凭折叠 permission UI 就报告审批绕过。
- view/result 点击不直接 execute；候选按钮只插入，没有发现点击候选直接 dispatch。
- `HomeController` 有 generation 检查，destroy 释放 retained ref，并传 AbortSignal；没有充分证据报告“必然重复创建主会话”或内存泄漏。
- 通用 WorkCard 是否出现布局遮挡、真实输入是否位于期望底部，缺完整可交互实机验证；提交的四张组件画廊截图不能证明实际 native composer/长对话布局。
- 42 个验收项的台账明确没有 PASS；不把作者已经明确注明的 BLOCKED/NOT_RUN 误报为造假。
- SettingsPanel 的来源范围/历史仅文案、没有编辑与历史列表；这是公开承认的 T21 PARTIAL 产品缺口，应在完成度结论列明，不包装成已经复现的漏洞。
- `useComposerBlock` 声明但未使用、`modelMissing` 只看初始 home capabilities，可能导致原生模型状态变化后提示过时；尚未完成真实模型更改验证，未作为确定发现。

## 建议跨轮反证

1. 另一审查者独立寻找是否存在 controller 的隐式 event 更新；若没有，复跑 FE-01。
2. 对照 rc.3 公开 input contract 确认 FE-02；rc.2 已足以影响 declared engines 中的一个正式版本。
3. 用真实原生 editor 复现 FE-03 草稿/chip 删除；确认 send 中 setDraft 是否进一步破坏未完成提交。
4. 后端审查者确认任务结果确实可通过 detailV2 带检查失败与 artifacts；让前端样例覆盖这些字段后验收 FE-05。
