import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
import {BoopDatabase as V1Database} from './baseline/dsh-boop/src/host/persistence/database.ts'
import {BoopRepository as V1Repository} from './baseline/dsh-boop/src/host/persistence/repository.ts'
import {BoopStorage,deriveScopeIdentity} from './repo/dsh-boop/src/host/persistence/storage.ts'
import {HomeService} from './repo/dsh-boop/src/host/home/service.ts'
import {mainSessionFacts} from './repo/dsh-boop/src/host/main-session.ts'
import {gateHomeReferences} from './repo/dsh-boop/src/host/home/reference-guard.ts'
import {encodeSessionReferenceUri,formatSessionReferenceMention} from './repo/dsh-boop/src/shared/session-mention.ts'
import {apply as applyHost} from './repo/dsh-boop/src/host/index.ts'

const results=[]
// Attempt to disprove PERSIST-1 by supplying an existing, compatible legacy
// session, instead of only a legacy database binding to a missing native id.
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'boop-cross-existing-'))
try{
  fs.mkdirSync(path.join(dir,'boop'),{recursive:true})
  const scopeId=deriveScopeIdentity(dir).scopeId
  const old=new V1Database({path:path.join(dir,'boop','boop.sqlite'),fts:false})
  old.bootstrap()
  const oldRepo=new V1Repository(old)
  oldRepo.ensureScope(scopeId,'dsh-local-owner')
  oldRepo.bindMainSession(scopeId,'boop-main')
  old.close()
  const storage=new BoopStorage({dshHome:dir})
  const facts=storage.start()
  assert.equal(facts.ok,true)
  const sessions=new Map([['boop-main',{session:{id:'boop-main'},ctx:{on(){}}}]])
  const resolved=[]
  const native={
    async resolve(id){resolved.push(id);return{ok:sessions.has(id),agent:sessions.get(id)}},
    async observe(id){return{exists:sessions.has(id),subagent:false,archived:false,preset:'boop',cwd:path.join(dir,'boop','home')}},
    async create(input){sessions.set(input.sessionId,{session:{id:input.sessionId},ctx:{on(){}}});return{sessionId:input.sessionId}},
    async flush(){return true},async modelAvailable(){return true}
  }
  const home=new HomeService({db:storage.db,scopeId,ownerId:'dsh-local-owner',dshHome:dir,native,policy:{decide:()=> 'allow'}})
  const created=await home.ensureHome()
  const oldIdentity=mainSessionFacts({boop:{state:()=>({storage:facts}),storage:()=>storage}})
  assert.equal(created.data.state,'ready')
  assert.equal(oldIdentity.mainSessionId,'boop-main')
  assert.notEqual(created.data.mainSessionId,oldIdentity.mainSessionId)
  assert.equal(resolved.includes('boop-main'),false)
  assert.equal(sessions.size,2)
  results.push({id:'PERSIST-1',verdict:'CONFIRM',variant:'legacy native Session exists with compatible preset and cwd',homeId:created.data.mainSessionId,legacyApiId:oldIdentity.mainSessionId,legacyWasInspected:false,physicalSessionCount:sessions.size})
  storage.close()
}finally{fs.rmSync(dir,{recursive:true,force:true})}

// Do not replace prepare(): execute the official parser, prepareDirectMessages,
// prepare, normalization and budget code until the exact native readSurface call.
const nm=path.resolve('repo/dsh-boop/node_modules/.pnpm')
const referenceDir=fs.readdirSync(nm).find(n=>n.startsWith('@deepseek-ai+dsh-session-reference@'))
const official=await import(pathToFileURL(path.join(nm,referenceDir,'node_modules/@deepseek-ai/dsh-session-reference/lib/index.js')).href)
const proto=official.SessionReferenceResolver.prototype
const input=formatSessionReferenceMention({sessionId:'blocked-outer',label:encodeSessionReferenceUri('secret-session')})
const output=gateHomeReferences([{id:'m1',source:{kind:'user'},content:[{type:'text',text:input}]}],{decide:()=> 'deny'})
const reads=[]
const receiver={
  config:{maxReferences:3,maxReferenceBytes:65536},
  ctx:{sessionQuery:{async readSurface(id){reads.push(id);throw new Error('stop-after-read-capture')}}},
  referenceBudget:proto.referenceBudget,prepare:proto.prepare
}
await assert.rejects(proto.prepareDirectMessages.call(receiver,{id:'boop-home',session:{id:'boop-home'}},output),/failed to read referenced session: stop-after-read-capture/)
assert.deepEqual(reads,['secret-session'])
results.push({id:'PERSIST-3',verdict:'CONFIRM',policy:'deny all',officialReadSurfaceCalls:reads,actualReadBody:'intentionally stopped before any real data access',guardOutput:output[0].content[0].text})

// Use the actual successor storage acquisition, not a fabricated successor
// holder/token. Only the old expiry timestamp is advanced to model suspension.
const fenceDir=fs.mkdtempSync(path.join(os.tmpdir(),'boop-cross-fence-'))
const cleanup=[]
let successor
try{
  const sessions=new Map()
  let creates=0
  const ctx={logger:{info(){},warn(){}},dshHomePath:()=>fenceDir,
    provide(name,value){this[name]=value},effect(fn){cleanup.push(fn())},
    reflect:{get(name){return name==='sessionProjections'?{stateOf(){return 'boop'}}:null}},
    sessionController:{
      async create(input){creates++;sessions.set(input.sessionId,{id:input.sessionId,header:{cwd:input.cwd},ctx:{on(){}}});return{sessionId:input.sessionId}},
      async resolveAgent(id){const session=sessions.get(id);return session?{session,ctx:session.ctx}:null}
    },sessions:{get:id=>sessions.get(id),async flush(){return true}}
  }
  applyHost(ctx)
  const original=ctx.boop.storage()
  original.db.db.prepare('UPDATE runtime_lease SET expires_at=? WHERE scope_id=?').run(Date.now()-1,original.identity.scopeId)
  successor=new BoopStorage({dshHome:fenceDir,holder:'cross-successor'})
  assert.equal(successor.start().ok,true)
  assert.equal(original.checkWrite().ok,false)
  const reply=await ctx.boop.ensureHome()
  assert.equal(reply.data.state,'ready')
  assert.equal(creates,1)
  results.push({id:'PERSIST-4',verdict:'CONFIRM',variant:'real second BoopStorage.start() acquired expired lease',oldFence:original.checkWrite(),nativeCreatesAfterTakeover:creates,homeState:reply.data.state})
}finally{
  successor?.close()
  for(const fn of cleanup) if(typeof fn==='function')fn()
  fs.rmSync(fenceDir,{recursive:true,force:true})
}
fs.writeFileSync('cross-frontend-validation.json',JSON.stringify({head:'b92fa37ed67182916e133e5e60b4b970a858d5e8',results},null,2)+'\n')
console.log(JSON.stringify(results,null,2))
