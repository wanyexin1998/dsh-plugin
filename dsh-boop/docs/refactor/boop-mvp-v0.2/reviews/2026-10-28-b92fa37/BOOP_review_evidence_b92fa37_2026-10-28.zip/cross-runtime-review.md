# Cross-review by runtime reviewer: frontend findings

Head reviewed: `b92fa37ed67182916e133e5e60b4b970a858d5e8`. This is the third-round independent challenge pass requested by the parent reviewer. I inspected `frontend-validation.mjs/json`, the current source, and actual installed official DSH rc.2 contracts/implementation. I copied the validation script only to change its output filename, and ran `node cross-frontend-recheck.mjs`; exit 0, five reproduced outcomes in `cross-runtime-frontend-results.json` and `cross-runtime-frontend.log`. No product source or original reviewer artifact was changed.

## Decisions

| ID | Decision | Why the mock does or does not represent the real contract |
| --- | --- | --- |
| FE-01 task refresh missing | CONFIRM | No implicit refresh found after reviewing all `refreshTasks`, `listV2`, controller.mount, timer/subscription occurrences in client source. Connection callback only patches the string; drawer only changes display; native chat changes never call HomeController. The stub RPC supplies the correct data envelope consumed by this controller, and the failing refresh is a pure controller behavior. |
| FE-02 candidate reference insertion | CONFIRM | Official `SessionInput` has insertReference and state, but no top-level captureInsertion; `InputActions` has captureInsertion. Installed `SessionInputShell.actions.captureInsertion` includes draftRev. Exact native insertReference requires span.draftRev === this.rev. BOOP passes its `{start:0,end:0}` fallback without draftRev. The copied native method is not an invented permissive stub. |
| FE-03 continue replaces draft | CONFIRM | Official SessionInput.setDraft contract explicitly says replace the whole draft and remove inline reference chips; installed method invokes draftEditor.setDraft on plain text. Actual BOOP bundle calls this method unconditionally. The test's simple setter accurately captures replacement semantics; it does not prove DOM/IME/attachment effects, and those should not be claimed. |
| FE-04 stale catalog after later user message | CONFIRM with narrower wording | Actual legacy conversation record contracts do use `kind:'tool-result'`, name/call/content and user nodes; readWorkChoice scans backwards past every newer user node and ignores originUserMessageId/sourceSeq. TargetCandidates hides solely while phase != plain, so the old result can return afterward. This verifies stale selection, not automatic dispatch. The separate claim that deleting an inserted chip leaves disabled state follows source, but was not covered by this rerun. |
| FE-08 ready identity falsely unavailable | CONFIRM | Current Panel patches only mainSessionId and phase in the reused v1 store. No host facts update exists. The actual reused `mainSessionStatusLine` reports data-domain unavailable with host null. The VM substitutes rendering but obtains the actual store from plugin registration, so this assertion is valid at the state-contract layer. |

## Exact official-contract evidence inspected

- `node_modules/.pnpm/@deepseek-ai+dsh-client-ui-conversation@0.2.1-rc.2_@deepseek-ai+cordis@4.0.5/node_modules/@deepseek-ai/dsh-client-ui-conversation/lib/types/client/contract/input.d.ts:164-205,229-240`.
- Same package `lib/client.js:14913-14916` (actions capture with draftRev), `15008-15013` (setDraft replaces editor document), `15309-15314` (span revision comparison).
- Same package `lib/types/client/contract/records.d.ts:47,157-178` (legacy user and tool-result records); dsh-client-ui-chat snapshot contract re-exports these records.
- Product source `src/client/index.tsx:65-89,123-125`; `src/client/home/controller.ts:91-93,132,145-157,175-177`; `src/client/home/read-work-choice.ts:29-55`; `TargetCandidates.tsx:13-15`; `BoopSession.tsx:39-43,54-63`.

## Reachability corrections for final report

1. The current backend catalog/context output schemas already reject v2 results (runtime R1). Therefore FE-02 and FE-04 are independently confirmed UI defects that become reachable once the backend can return a valid catalog; do not say a real user successfully received such a catalog in this audit.
2. The missing backend driver (runtime R2) means new real work cannot currently finish. FE-01 remains a real missing synchronization path and would independently hide tasks/results after that driver is connected. It also affects data that changes through other windows or old persisted task rows today.
3. FE-03 destroys the unsent text when an actionable work card is present; the test establishes text/chip replacement, not that an unauthorized deployment actually occurred.
4. These five findings are not visual-browser passes. A VM-loaded actual client bundle plus official native method is contract-level evidence. No real Lexical DOM, IME composition, screen reader, or screenshot rendering was validated by this pass.

No candidate was rejected on this cross-pass. The frontend reviewer already kept these evidence limits mostly clear; the final report should retain them.
