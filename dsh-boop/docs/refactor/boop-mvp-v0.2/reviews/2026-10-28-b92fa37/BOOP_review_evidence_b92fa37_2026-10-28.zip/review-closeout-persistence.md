# 持久化审查者收尾校准

目标提交：`b92fa37ed67182916e133e5e60b4b970a858d5e8`。

本次只读复核最新 `runtime-probes.mjs` / `runtime-probes.log`，未改产品、未重跑大测试。最新日志为 10 个故障断言通过。

## R-DELIVERY 加强版：确认已解决此前的 pending 去重反证

**裁定：CONFIRM 控制器重复回传缺陷；继续保留完整生产路径尚未接线的限制。**

新的 probe 提取并运行安装包中未经修改的 `ReactLoopInbox` 方法，先以对照样例证明同 ID 仍 pending 时会拒绝，再 claim 第一条消息使其离开 pending，随后用相同 ID 再 append。它不再把“同 ID 两条消息同时 pending”当作宿主行为。实际输出是：第一次结果已 claim 1 条，第二次同 ID 结果重新 pending 1 条。因此我此前对简单数组 fixture 的反证已解决。

最准确的影响表述：**结果第一次已经被 native inbox 消费，但 BOOP 未得到或未保存可确认的投递回执时，后续 `deliver()` 会再次投递同一结果 ID；native 仅针对当前 pending 去重，不能替代 BOOP 的历史投递确认，结果可能重复进入主会话。**

前置条件与证据边界：

- 有 result_outbox 待确认项，首次结果已经被 claim；随后发生响应/回执不确定，再调用 deliver。
- probe 使用正式 inbox 方法，但 Session append、projection 和事件总线仍是隔离替身；没有真实模型或真实用户会话。
- “端口在 claim 后抛错”是失败注入，并非证明当前同步生产 followup 必然这样抛错；对应的实际风险窗口还包括 first enqueue/claim 后回执持久化之前的异常、重启，以及 flush 后消息已消费而 visible 无历史判断。
- 当前插件没有生产调用 `deliver()`，所以这是已复现的回传控制器缺陷，不能写成当前正常 UI 已观察到重复结果。

## R-REVISION-CONSTRAINTS：确认约束确实持久化丢失

**裁定：CONFIRM revision 控制器缺陷，执行影响属于接线前必须修复的 latent 风险。**

新 probe 使用新鲜、同目标 context，并以“显式完整传入”作为对照。省略可选 criteria/exclusions 时，真实 task v2 行变成两个空数组，新 action payload 也不包含原限制；显式再次传入时，原“不要部署”等值保留。因而不能归咎于过期 context、换目标或 mock 读取错误。

最准确的影响表述：**用户追加一项要求时，如果调用方没有重复提供完整验收条件和排除项，`revise()` 会把此前条件清空；新版本的持久化规则及后续投递的 exclusions 因此丢失。** 不能声称已实际部署、已产生外部破坏，也不能假设目标 Agent 一定忘记历史中的原文；问题是控制器不再明确维护这些限制。

前置条件：任务原有非空条件/排除项；新 revision 仅补充 instruction、没有明确要求清除这些规则。当前完整工具与执行链尚有 schema / tick 接线阻断，应在连通前修复默认继承，只有用户明确修改/清除时才替换。

## PERSIST-3 与 PERSIST-5 的共同影响

PERSIST-3 已证明 guard 输出中的内层 URI 被正式 native parser / prepareDirectMessages 消费，达到受限来源预读取路径；**没有证明模型已收到私密内容，更没有证明内容被外传**。PoC 仅捕获预读取目标，未读取真实秘密。

PERSIST-5 的通知缺 id / role，会在之后正式 `user/message` append 验证时失败，可能阻止该轮进入模型请求。因此不得把“预读取发生”直接写成“模型已看到”。先后顺序也意味着不能用后续聊天失败否认前面引用保护失效。

建议合适表述：**引用范围保护存在二次解析绕过；拒绝后的说明消息又不符合原生消息协议。前者让受限引用进入预读取路径，后者使合法的拒绝流程报错。两项都需修复，并分别验收实际读取目标与正式消息入账。**

none / selected / unknown 策略是这两项限制分支的前提；当前 setAccess 尚未接 UI / remote，也应在完整报告中保留这个实现现状。

## 最终校准：PERSIST-5 的失败时点（取代上文 append 因果）

**本节 supersedes 上文所有“正式 append 验证会失败 / append 失败可能阻止模型请求”的表述。** 后续前端独立反证对正式 API 做了直接对照：正式 `Session.append('user/message', notice, ...)` 接受这个缺少 `id` / `role` 的 notice；随后对该事件执行 `snapshotSessionEvent` 才会拒绝。因此不得把快照边界的验证行为等同于 append 边界，也不能推断此 notice 必然在模型请求前被阻断。

PERSIST-5（最终报告 R08，P2）的准确范围是：**guard 产生不符合原生消息协议的事件，该事件能够进入 Session log，而后续标准快照读取会以缺少 identified message 等协议错误拒绝它，影响相应历史读取 / 查询路径。** 不能声称 append 自身必然失败；具体生产查询或恢复流程在哪个时点暴露该错误，应以正式快照对照和调用链为准。

PERSIST-3（最终报告 R07）的证据范围保持不变：已证明受限 session ID 进入正式 native 引用预读取路径；**没有证明真实模型收到或外传私密内容**。但也不应再以 PERSIST-5 必定阻断 append 为理由，断言模型一定收不到。现有证据只能支持预读取绕过与后续快照协议失败这两个分别验证的结论。

此项对照由前端审查者合入 PERSIST-5 探针；本次仅校准报告文字，没有修改探针或产品代码。
