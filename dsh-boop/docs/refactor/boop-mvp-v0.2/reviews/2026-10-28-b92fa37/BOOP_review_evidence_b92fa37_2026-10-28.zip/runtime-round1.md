# BOOP runtime first-round adversarial review

Scope: `dsh-boop` runtime diff from `6f9c046681e58a1304704baf165dce5de2a49f4f` to `b92fa37ed67182916e133e5e60b4b970a858d5e8`. Source unchanged. All line numbers below refer to head. Review date 2026-10-28. No real model or DSH user profile was exercised. Findings from service-level failure injection are explicitly separated from defects reachable in the currently wired product.

## Evidence and coverage

- Read every changed line in `src/host/delegation/service.ts`, `src/host/delegation/projection.ts`, `src/host/tools.ts`, `src/host/tasks-api.ts`, `src/host/gate/pre-step.ts`, `src/host/api-service.ts`, and `tests/unit/mvp-delegation.test.mjs`.
- Traced relevant unchanged/new dependencies: `src/host/index.ts`, `src/host/home/native-session.ts`, `src/host/transport/command-envelope.ts`, `src/host/transport/dsh-adapter.ts`, schema/database declarations, `cordis.patch.yml`, `presets/boop.patch.yml`, and plan requirements concerning provenance/context/queue/stop/delivery.
- Read installed official rc.2 `dsh-tools` ToolRunContext and `ToolRuntime.createSuccessResult`; `dsh-session-query` observation/event-record contracts; `dsh-session` SessionHeader; `dsh-agent-loop` followup/inbox implementation. These are actual installed declared peer dependencies, not invented host contracts.
- `runtime-probes.mjs` imports the reviewed source unchanged and now runs 10 targeted `node:test` cases via `node runtime-probes.mjs`; all 10 observed the asserted bad behavior, log `runtime-probes.log`. The tenth case was added in the final targeted constraints challenge.
- `node --test runtime-probes.mjs` in this particular environment only reported the containing file, without the individual test logs. Do not cite that invocation as a ten-case run. The direct `node` invocation printed all 10 cases and evidence.
- No repository edits, real messages, remote writes, or real dispatches occurred. This is a manual review, not a completed formal security-plugin scan.

## R1 — P1 — Both indispensable model tools violate their registered output schemas

**Location:** `src/host/tools.ts:77-93,103-125` and `243-259,263-277`.

The implementation changes `boop_catalog` and `boop_context` to return the new `{schemaVersion,kind,ok,data}` envelope, but keeps their old closed output schemas (`additionalProperties:false`). The actual installed `dsh-tools` runtime validates every successful tool body value before rendering (`ToolRuntime.createSuccessResult`, installed `lib/index.js:3637-3641`). It throws `ToolOutputError` for every new envelope: `value.schemaVersion`, `value.kind`, `value.ok`, and `value.data` are undeclared properties. Error envelopes fail the same old schema.

**Current reachability:** Directly reachable in the shipped real tool runtime whenever a new catalog/context mode is invoked. No missing worker or model-provider-specific behavior is required for the contract failure.

**User effect:** BOBO cannot return real session candidates or the context token needed for dispatch. A service-unit-test success does not establish that the model can use these tools.

**Validation:** R-SCHEMA uses real registered `defineTool` outputs and calls the installed official `ToolRuntime.prototype.createSuccessResult`; both throw. Not a mock validation algorithm.

**Fix/acceptance:** Register the canonical v2 response schema (including failures) for these tools; keep legacy mode compatibility explicitly if needed. Test through actual ToolRuntime, not only `DelegationService` or `definition.execute`.

## R2 — P1 — The new execution controller and result publisher have no production callers

**Location:** `src/host/delegation/service.ts:449-471,474-525,648-681`; composition `src/host/index.ts:148-169,266-291`; `src/host/tools.ts:326-332`.

`prepare` durably creates a planned action/outbox and returns queued. `index.ts` constructs the service and calls only `bootRecover()`/`inheritAccess()`. Exhaustive search of `src` finds no production call to `DelegationService.tick()` or `deliver()`, no timer/event-loop wakeup, and no old scheduler bridge to the new controller. Calls exist only in synthetic tests. `reconcile` is exposed on the UI but does not start prepared work.

**Current reachability:** Current shipping composition; independent of model output schemas. Even after fixing R1 and obtaining a task, it never leaves queued automatically.

**User effect:** Real delegated work is never sent. Results are never automatically returned. This is not an environment-only test gap.

**Validation:** Static complete call-site search; `tests/unit/mvp-delegation.test.mjs:195,213,224` explicitly supplies the missing manual ticks. The task remains `planned` without that external invocation by construction.

**Fix/acceptance:** Connect a lifecycle-owned scheduler/observable loop, wake on prepare/revise/state changes, observe active actions, publish result outbox, enforce fence, and dispose it. Demonstrate real tool → native target → return without calling controller internals from the test.

## R3 — P1 — Real host adapter cannot observe running/terminal work and does not read semantic context

**Location:** `src/host/home/native-session.ts:124-175,178-180,200-220`; consumers `src/host/delegation/service.ts:572-645,709-734,885-909`.

Native `observe` hardcodes `pendingHuman:false`, `pendingMessage:false`, `turnId:null`, `turnTerminal:false`, `ownership:'unknown'`, `summary:null`, `deliverable:false`, and empty checks/artifacts. `visible` is always false and `mainIdle` always true. `busy` reads `observed.live`/`header.running`, whereas real `SessionObservation` uses `source:'live'|'prepared'` and has no `live` field; SessionHeader has no running field. `subagent` reads nonexistent `parentSessionId`, whereas real header has `parentSession` and `origin:'subagent'`; `home` is always false.

`readEvents` invokes `listEvents`, whose official return is lightweight `{sessionId,seq,type,time,surface:'current'|'shadowed'|'log-only'}`. It then uses `event.surface?.text ?? event.type`, so actual model context consists of names like `user/message` and `turn/end`, not the user's requirements or code agent replies. `beforeSeq` is ignored. The bound generation is the session format version, not a content generation, and latest user watermark is the raw log head.

**Current reachability:** Adapter methods are used by the wired read-context/catalog path, though R1 currently prevents returning successful new tool results. Execution/stop effects are latent until R2 is connected.

**User effect:** After controller wiring, busy sessions are not reliably held, children/home can be treated as ordinary targets, a successful native run cannot reach completed/delivered, stop cannot establish ownership or cancel an owned turn, and reconcile can mistake an unobserved run for absence. Context cannot carry the target's real restrictions.

**Validation:** R-NATIVE invokes the actual adapter against official-shaped observation/event records. It returns no terminal/ownership/summary despite a turn-end event; event texts are only event types. Persistence reviewer independently checked the observation and header types.

**Fix/acceptance:** Implement a durable action → exact message → exact turn → terminal projection with current inbox/approval/human-takeover facts; obtain real semantic events with source watermarks; supply correct title/workspace/subagent/home facts; use exact persisted evidence for visibility. Test this adapter, not a port whose test fills those facts manually.

## R4 — P1 — Tool-call identity is accepted as direct-user provenance without checking main binding

**Location:** `src/host/tools.ts:36-54`, global registration `cordis.patch.yml:18-19`, use `326-332,350-369`.

`trustedCall` ignores the retrieved HomeService, accepts any `exec.agent.session.id`, and sets `originKind:'user'` whenever either an undocumented origin field or ordinary `exec.callId` is present. Official `ToolRunContext` provides callId/agent/rootCallId, not a direct-human origin marker. No main binding/preset check, current turn-origin inspection, or exclusion of `boop-result`/other plugin sources occurs. Global BOOP tools are registered outside the BOOP preset as well.

**Reachability qualification:** The tool implementation accepts this identity today; R1 prevents the normal full catalog/context path from producing a visible token. The dispatch bypass is therefore a separately demonstrated latent authorization bug behind that current upstream blocker. Do not claim a real unauthenticated exploit or actual remote dispatch occurred.

**User effect once upstream blockers are repaired:** Ordinary sessions or a model turn caused by a result/context message can create work under the authority of a human who did not just request it; results may target the ordinary session instead of the canonical home.

**Validation:** R-PROVENANCE registers actual tools, executes context/dispatch under an agent with session `ordinary-session` and only `callId:'model-call-with-no-direct-user'`, and verifies the created `action_runtime.main_session_id`/`origin_message_id` contain those values although scope main is `main`.

**Fix:** Build TrustedCall from verified current home binding/preset and durable direct-human origin of the root tool call; reject result/automation/non-home origins. Keep deliberate user intent judgment in the agent, but do not invent machine provenance from callId.

## R5 — P1 — Context can be stale at preparation, then silently re-stamped as fresh

**Location:** `src/host/delegation/service.ts:407-425,452-455,503-508`.

Snapshots store origin, generation, head and direct-user watermark. `prepare` checks only target/main/time/policy, not origin message, generation, head or latest direct user. It observes the target again and stores the *new* user watermark/generation into action_runtime without requiring the context to have read them. Tick compares current target against that re-stamped runtime, so it permits an instruction derived from old context after a new direct-human restriction.

**Reachability:** Service defect, masked in the current full product by R1/R2. A corrected worker still sends stale work unless this is fixed independently.

**Validation:** R-CONTEXT reads snapshot at direct-user seq 3, adds seq 8 with new instructions, calls prepare under a different originating main user message, and observes a native followup after tick. No intervening fresh context was read.

**Fix:** Validate the stored snapshot against the current bound origin/target generation/direct-user watermark before accepting; refresh semantic context deliberately and require user reconfirmation on new direct-human constraints. Do not overwrite the check target with new facts without having used them.

## R6 — P1 — Scope revocation/target changes are not rechecked before dispatch or pre-step

**Location:** `src/host/delegation/service.ts:500-524,527-542`; `src/host/gate/pre-step.ts:494-500`.

A task may pass access checking during prepare and then wait. Tick checks generation/user watermark/busy but not current source access, policy epoch, archived/subagent/home status, or latest task version/stop state inside the claim. v2AdmissionAllows checks only action state by message ID; it ignores scope/target/policy/stop/previous admission. Thus a queued request can proceed after the user narrows source_access to none. The actual `setAccess` remote remains a separate wiring question; this test establishes the controller contract.

**Reachability:** Latent execution bug behind R1/R2; additionally important when queued persisted rows or UI access wiring are enabled.

**Validation:** R-REVOKE prepares while target busy; setAccess(mode:none) increments epoch to 2; target becomes idle; tick sends exactly one followup under stale epoch 1.

**Fix:** Revalidate current policy/target/identity/fence immediately before claiming and before native admission; block or invalidate stale queued actions. Repeat after awaited observations, inside the relevant transaction/CAS boundary.

## R7 — P1 — Stop after a revision stops only the queued revision and reports success while old work still runs

**Location:** `src/host/delegation/service.ts:692-707,737-787,1068-1071`.

Revising while v1 is running creates planned v2 (`queueReason:'previous_action'`). `stop` selects only latestAction, stops planned v2, and returns disposition/productState stopped. It never inspects/cancels the old v1 currently holding execution_slot. This is distinct from an inability to identify native ownership: it reproduces even with an accurate port proving the old turn is exclusive BOOP work.

**Reachability:** Controller-level latent execution bug behind R2; sequence is supported by the new revise API.

**Validation:** R-STOP-REVISION runs v1, makes v2 planned, then stops task version 2. Response says stopped; v1 remains running; slot is held by v1; cancel calls = 0.

**Fix:** Stop the task's future actions and independently track the actually occupied action; cancel only its proven exclusive native turn, wait for confirmation, and project stopping/future-only truthfully.

## R8 — P1 — Result publisher retries an uncertain send without checking native pending/durable receipt first

**Location:** `src/host/delegation/service.ts:650-679`; native visibility `src/host/home/native-session.ts:208`.

`deliver` selects pending/sending/unknown, checks only `visible`, and calls followup again. It does not write sending before external I/O or inspect pending before resend. Real adapter visible is permanently false. Native inbox rejects duplicate IDs only while they are pending; installed `dsh-agent-loop` `ReactLoopInbox.mutate` checks current inbox IDs, so once claimed this does not provide historical deduplication. A crash/lost response or flush failure after successful consumption permits a later identical result message/extra model turn.

**Reachability:** Latent publisher bug because R2 never invokes deliver. Evidence is failure injection plus source trace, not live duplicated user messages.

**Validation (strengthened in cross-review):** R-DELIVERY evaluates the exact installed internal `ReactLoopInbox` implementation, substituting only its projection/session-storage/event-bus dependencies. Control: two inserts of the same ID while pending throw `already pending`. Main scenario: the first result is enqueued and **claimed**, then the response is lost; on the next deliver call, the same ID is admitted again by the exact native inbox. There is one already-claimed occurrence and one new pending occurrence, not two equal IDs simultaneously pending. The outbox then reports sent. No real model/profile is used.

**Fix:** Persist sending first; reconcile exact stable message ID in both pending and durable history; never blindly resend an unknown delivery; bind to the correct main binding/version; serialize publisher runs.

## R9 — P1 — Mixed human/BOOP admission does not consume admitted messages

**Location:** `src/host/gate/pre-step.ts:413-425,439-456,494-515`; compare ordinary path `248-254`.

The new mixed-batch branch increments allowed and records best-effort admission but never adds the command ID to consumed. Durable `action_admission` is neither checked by v2AdmissionAllows nor required to be written. Thus repeated claims of an action still in dispatching/accepted/running are admitted again. Mixed batches should preserve human messages, but this change drops the one-execution guarantee in the shared gate.

**Reachability qualification:** A repeated native BOOP message must be present (recovery/replay/retry). The missing v2 worker blocks the new normal path today; old BOOP transport/gate continues sharing this code. No claim that ordinary text alone forges a durable host action.

**Validation (strengthened in cross-review):** R-MIXED uses actual `runtimeGatePortOf`, actual SQLite action/admission rows, and the action/message created by actual prepare/tick. First mixed admission persists `action_admission.turn_id='turn:1'`. A second mixed claim of the same command still returns enter; the row remains turn:1 because ON CONFLICT does nothing, and consumedMessageIds stays empty. A pure-BOOP control on the actual gate rejects its second claim. This is no longer a constant-true v2AdmissionAllows stub.

**Fix:** Unify atomic admission/consume across pure and mixed batches; verify durable message/action/target/turn identity, reject previously admitted commands, preserve human-only remainder. Treat failure to persist required admission as a blocked BOOP entry.

## R10 — P2 — Workspace-selected access authorizes reading but always rejects dispatch

**Location:** `src/host/delegation/service.ts:418-425` vs `225-237,324`.

prepare calls canRead(targetSessionId, null) before observing the target workspace. With access mode selected and only workspace IDs, readContext succeeds (it passes observed.workspaceId) but dispatch denies because null cannot match selected workspace. This breaks a documented mode rather than requiring additional authorization.

**Reachability:** Controller contract reproduced; current settings remote wiring may additionally be missing. Full product has R1 first.

**Validation:** R-WORKSPACE selects workspace `ws` with no individual session IDs; context succeeds, dispatch returns SCOPE_DENIED for a target in `ws`.

**Fix:** Observe exact target first and pass its canonical workspace into the same access predicate; repeat authorization consistently at later boundaries.

## Additional concrete risks kept separate from top findings

- `revise` omitted-constraint concern was promoted to confirmed R11 below after the final targeted probe and plan check.
- `latestAction` orders by millisecond created_at then random ID, not task_version (`1068-1071`), so same-millisecond revisions can be mis-selected. Not yet independently probed; do not mark confirmed from speculation.
- `setAccess`, `prepare`, `confirm` validate outside the queued DB transaction, allowing stale checks if concurrent UI calls interleave. Fence issues assigned to persistence reviewer. Keep unresolved rather than broad overclaim.
- `confirm` correctly keeps failed check evidence unchanged, and denies `originKind:'user'`. The UI transport's actual authenticated-principal policy was not proven vulnerable; do not claim unauthenticated acceptance.
- No direct SQL injection found in the new SQL paths: parameters are bound. No shell construction in the assigned new controller paths.
- Results are versioned rows and acceptance checks exact result/task version. Existing tests do establish this service-level separation even though real observation/delivery remain disconnected.

## Summary for parent

R1 and R2 independently block the intended core user flow today. R3 contains actual adapter contract errors that remain after wiring. R4-R9 are dangerous additional controller/boundary defects demonstrated in isolated service/gate tests; they must be fixed before connecting the missing production driver, but should not be described as real tasks already executed in this audit. R10 is a confirmed allowed-scope correctness failure.

## R11 — P1 — A small revision silently drops previously effective task restrictions

**Location:** `src/host/delegation/service.ts:762,768-779`; downstream `535-536`; optional contract `src/shared/mvp-contract.ts:206-211`.

`ContinueArgs.criteria` and `exclusions` are optional. For an existing task with `exclusions:['不要部署']`, a fresh-context revision whose new instruction is only `再改页脚` writes both task criteria/exclusions to `[]`. The new action persists only raw revision args, with no inherited criteria/exclusions. `sendClaimed` later reads that payload and sends `args.exclusions ?? []`, so the persisted constraint does not survive in the next command. `goal` explicitly inherits the old value when omitted, but restrictions do not.

**Plan check:** The plan requires persistent task constraints (MD line 157), effective restrictions before context/delegation (172,935), latest effective human instructions taking priority (A12 at 3752 onward), and a **complete revision snapshot** when continuing (1116). It does not literally specify a PATCH rule saying “undefined inherits”; nevertheless, dropping an unretracted explicit restriction solely because an optional model argument is absent contradicts these constraints. If the intended API were full replacement instead, missing fields would need rejection plus explicit reconstruction, not silent empty arrays. This is a behavioral inference from those stated requirements, not a fabricated verbatim specification.

**Validation:** Tenth case R-REVISION-CONSTRAINTS uses a fresh context for the same target and two independent actual databases/controllers. Both begin with criterion `标题不溢出` and exclusion `不要部署`. Omission branch: actual task rows become `criteria_json='[]'`, `exclusions_json='[]'`; new action payload contains instruction `再改页脚` and no restrictions. Control branch: explicitly passing the complete existing criteria/exclusions preserves them in both task row and new action payload. Neither branch performs a real native dispatch.

**Reachability:** Independently confirmed service-level latent bug behind the current catalog/context schema and worker-wiring blockers. It is not evidence that any real deployment happened.

**Fix/acceptance:** Normalize a complete effective revision before hashing, task update, revision snapshot and action payload. Omitted fields must preserve currently effective constraints, or be rejected when complete reconstruction is required. Removing a restriction needs actual new human intent, not mere omission. Regression acceptance: with `不要部署` already effective, `再改页脚` and fresh same-target context preserve it consistently in task row, revision snapshot and dispatched payload; an explicit full-value control remains unchanged. Do not rely on the model to repeat every historical safety condition on every call.
