import assert from 'node:assert/strict'
import fs from 'node:fs'
import { HomeController } from './repo/dsh-boop/src/client/home/controller.ts'

const task = { taskId: 'task', taskVersion: 1, title: '正在执行的工作', productState: 'running', latestResult: null }
const home = { state: 'ready', mainSessionId: 'home', bindingVersion: 1, capabilities: { send: true, reasonCodes: [] } }
let failed = false
const controller = new HomeController({
  async call(endpoint) {
    if (endpoint === 'boop/ensureHome') return { schemaVersion: 2, kind: 'boop.home', ok: true, data: home }
    if (endpoint === 'boopTasks/stop') {
      failed = true
      return { schemaVersion: 2, kind: 'boop.control', ok: false, error: { code: 'TASK_VERSION_CONFLICT', message: '工作已更新，停止没有发生' } }
    }
    if (endpoint === 'boopTasks/listV2') return failed
      ? { ok: false, error: { message: 'simulated disconnect while refreshing' } }
      : { schemaVersion: 2, kind: 'boop.tasks', ok: true, data: { items: [task] } }
    throw new Error('unexpected endpoint')
  },
  retain() { return { id: 'home', native: {}, ready: Promise.resolve(), release() {} } },
  connection: { getSnapshot: () => 'connected', subscribe: () => () => {}, reconnect() {} },
  selectPanel() {}, openSource() {}, async insertReference() { return true }, async setDraftText() { return true },
})
await controller.mount()
assert.equal(controller.getSnapshot().tasks.length, 1)
await controller.stopTask(task)
assert.equal(controller.getSnapshot().tasks.length, 0)
assert.equal(controller.getSnapshot().notice, null)
assert.equal(controller.getSnapshot().phase, 'ready')
const result = { id: 'FE-06', finding: 'CONFIRMED', stopRejected: true, refreshFailed: true, remainingVisibleTasks: controller.getSnapshot().tasks.length, visibleErrorNotice: controller.getSnapshot().notice, phase: controller.getSnapshot().phase, limitation: 'isolated actual controller; no live browser or network' }
controller.destroy()
fs.writeFileSync(new URL('./review-error-path.json', import.meta.url), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result, null, 2))
