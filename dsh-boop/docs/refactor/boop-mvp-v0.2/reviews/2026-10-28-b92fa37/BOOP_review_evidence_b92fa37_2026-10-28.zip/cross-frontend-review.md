# 第三轮交叉反证：身份、引用范围与 writer fence

审查者：前端独立审查分工；目标 `b92fa37ed67182916e133e5e60b4b970a858d5e8`。

审读 `persistence-adversarial.mjs` 与首轮报告后，重新运行该脚本，4 个案例仍通过。另创建独立脚本 `cross-frontend-validation.mjs`，用更贴近生产的变体尝试推翻重点结论；3 项均 **CONFIRM**。输出见 `cross-frontend-validation.json`。没有改产品代码或其他审查脚本。

## PERSIST-1：CONFIRM；保留身份分裂结论，限制后续影响表述

**试图推翻的理由**：首轮 native fixture 里没有旧 `boop-main` 的真实 Session，是否仅因 fixture 不完整才新建？旧主 Session 如果存在并满足 preset/cwd，是否会正常继承？

**独立验证**：仍从基线代码创建真实 v1 SQLite 并迁移，再提供一个确实存在的 `boop-main`，preset=boop、cwd=当前预期 home、非归档/非子代理。`HomeService.ensureHome` 连旧 ID 的 resolve 都没调用，仍新增另一 native Session，返回新 ID ready。再调用真实 `mainSessionFacts()`，返回旧 ID。最终两个物理 Session，两个接口宣称不同的主身份。

**根因**：migration 不回填 history；`HomeService.binding()` 只看 history；`bind()` 的 scopes CAS 受旧非空 ID 阻止，但不检查 affected rows，仍提交新 current-history。

**已证实影响**：已有聊天被留在旧主会话；新页面开启另一会话；`boop/mainSession` 与 `boop/ensureHome` 不一致；`tasks-api.ts:337` 的 UI trusted context 明确仍读取旧 scopes 主 ID。

**不应夸大**：不能说所有新派工/结果肯定路由到旧会话，因为工具可信上下文在当前代码里直接采用调用 agent.session.id，result_outbox 也从 action runtime 记录这一 ID。也不能直接说旧聊天数据被删除；它仍保留。报告应表达“身份权威分裂、继承失败和上下文不一致”，而非一律任务不可执行或历史丢失。

## PERSIST-3：CONFIRM；从消费引用推进到真实原生 readSurface 调用

**试图推翻的理由**：首轮只 spy 了 `prepare()`，会不会真实 prepare 的规范化、自引用限制、budget 或权限检查在读取前挡住？会不会官方 parser 不会对 label 作第二次解释？

**独立验证**：读取安装的正式 `dsh-session-reference@0.2.1-rc.2` 实现。原生 prepend pre-step 在 `await next()` 后运行 `prepareDirectMessages`，确实重新解析 BOOP guard 返回的原 user 文本。独立脚本执行真实 `prepareDirectMessages`、`prepare`、`referenceBudget` 与 `normalizeReferences`；只在最终 `ctx.sessionQuery.readSurface(id)` 放捕获后抛错，避免访问真实内容。policy deny-all 后仍观察到 `readSurface('secret-session')` 调用。

**必要前提**：原消息 source.kind=user，原生 session-reference 已安装，攻击标签中内层 Session 与 BOOP 自身不同。用户粘贴合法 canonical mention 即满足，无需 forged tool result、模型执行权限或跨账户能力。宿主仍可能约束可读库范围，故这里证明的是 BOOP 限制层被绕过，不是远程账户 ACL 绕过。

**根因**：被拒绝外层 mention 转成 `parsed.text` 后，用户控制 label 包含的 `dsh-session:` 仍可被再次解析。当前“保留名称”没有保证输出不可执行。

**反证排除**：重复安装多个 guard 有时可能偶然去掉某一层，但首次 ensureHome 单个 guard 路径已可达；不能作为安全保证。真实 prepare 读取前没有 BOOP policy 再检查。

## PERSIST-4：CONFIRM；使用第二个真实 Storage 获取租约

**试图推翻的理由**：首轮直接 UPDATE holder/token，是否构造了实际 LeaseManager 不会产生的状态？是否 Host 统一 service wrapper 或 storage 自动拦写？

**独立验证**：执行真实 host `apply(ctx)`（Session 服务最小契约替身、SQLite 和装配代码真实）。只把旧租约到期时间设到过去模拟休眠，然后创建第二个真实 `BoopStorage`，经其实际 `start()` 获取过期租约。原 storage.checkWrite 返回 `fencing token superseded`。此时调用第一个 Host 真实暴露的 `ctx.boop.ensureHome()`，仍调用 native create 一次并返回 ready。

**根因**：production HomeService 构造不传 fenceOk，默认 true；它直接使用原生 SQLite handle 写 provisioning/binding，外层 API 没有统一 fence 防线。第二 Host 的成功接管不会自动撤销旧 home 对象。

**校准**：这次没有运行两个 OS Host 进程，也没有实际 sleep 15 秒；测试使用两个真实 Storage 实例与人为到期时间来隔离同一状态转移。它已经推翻“只有手改不可达 token 才能触发”的反证，不能包装为真实桌面双进程通过或失败。

## 附加检查

PERSIST-2 的读取限制结论也有直接源码支持：生产 excluded=false / hostCanRead=true；首轮实库中现存 rule/cursor 未删除但 canRead=allow。该问题无需依赖 PERSIST-3 的 label 绕过，应该保留为独立根因。未另行重复写第四个脚本案例。
