/** Isolated adversarial probes. Imports reviewed source unchanged. No real DSH profile/model. */
import assert from 'node:assert/strict'
import { test } from 'node:test'
import fs from 'node:fs'
import vm from 'node:vm'
import { BoopDatabase } from './repo/dsh-boop/src/host/persistence/database.ts'
import { BoopRepository } from './repo/dsh-boop/src/host/persistence/repository.ts'
import { DelegationService } from './repo/dsh-boop/src/host/delegation/service.ts'
import { createDelegationPorts } from './repo/dsh-boop/src/host/home/native-session.ts'
import { PreStepRuntimeGate, runtimeGatePortOf } from './repo/dsh-boop/src/host/gate/pre-step.ts'
import { apply as applyTools } from './repo/dsh-boop/src/host/tools.ts'
import { ToolRuntime, validateJsonSchemaValue } from './repo/dsh-boop/node_modules/@deepseek-ai/dsh-tools/lib/index.js'

function world() {
  const db = new BoopDatabase({ path: ':memory:', wal: false, fts: false })
  db.bootstrap()
  let clock = Date.parse('2026-10-28T00:00:00.000Z')
  const now = () => new Date(clock).toISOString()
  const repo = new BoopRepository(db, now, () => 'fixture')
  repo.ensureScope('scope', 'owner')
  const sessions = new Map()
  const calls = { followup: [], cancel: [], remove: [] }
  const ports = {
    now, nowMs: () => clock, fenceOk: () => true,
    listSessions: async () => [...sessions.values()],
    observe: async id => sessions.get(id) ?? null,
    readEvents: async id => sessions.get(id)?.events ?? [],
    excluded: () => false, hostCanRead: id => sessions.has(id),
    followup: async (id, message) => { calls.followup.push({ id, message }); sessions.get(id)?.inbox.push(message); return 'enqueued' },
    flush: async () => true,
    pending: async (id, mid) => sessions.get(id)?.inbox.some(m => m.id === mid) ?? false,
    visible: async () => false,
    remove: async (id, mid) => { calls.remove.push(mid); const s=sessions.get(id); s.inbox=s.inbox.filter(m=>m.id!==mid); return true },
    cancelTurn: async id => { calls.cancel.push(id) },
    mainIdle: async () => true,
  }
  const service = new DelegationService(db, 'scope', ports)
  service.inheritAccess('owner', 'fixture')
  const add = (id, more={}) => { const s={ sessionId:id, reachable:true,busy:false,pendingHuman:false,archived:false,subagent:false,home:false,title:id,workspaceId:'ws',workspaceTitle:'Project',activity:'idle',lastActivityAt:now(),preview:null,sourceGeneration:'generation-1',headSeq:4,latestDirectUserSeq:3,latestDirectUserMessageId:'user-1',pendingMessage:false,turnId:null,turnTerminal:false,ownership:'not_started',approvalId:null,summary:null,deliverable:false,checks:[],artifacts:[],missing:[],evidenceSeq:4,events:[{seq:3,text:'Do not deploy',sessionId:id,sourceGeneration:'generation-1'}],inbox:[],...more}; sessions.set(id,s); return s }
  add('main',{home:true}); add('target')
  const call={originRef:'user-request-1',originKind:'user',mainSessionId:'main',bindingVersion:1,policyEpoch:1,holder:'owner',fence:1}
  const context = (c=call) => service.readContext({targetSessionId:'target',call:c})
  const prepare = async (token,c=call,more={}) => service.prepare({requestId:'request-1',targetSessionId:'target',contextToken:token,goal:'Fix title',instruction:'Fix title without deployment',criteria:['No overflow'],exclusions:['Do not deploy'],...more},c)
  return {db,repo,sessions,calls,ports,service,call,context,prepare,add,advance:()=>{clock+=1000}}
}

test('R-SCHEMA: actual ToolRuntime rejects both new catalog and context envelopes', async () => {
  const w=world(); const defs=new Map()
  applyTools({tools:{register:d=>defs.set(d.name,d)},boop:{delegation:()=>w.service,home:()=>null,storage:()=>({identity:{scopeId:'scope',ownerId:'owner'},repo:w.repo,facts:()=>({lease:{fencingToken:1}})})},logger:{info(){},warn(){}}})
  const exec={agent:{session:{id:'main'}},callId:'call-1',rootCallId:'call-1',signal:new AbortController().signal}
  for(const [name,args] of [['boop_catalog',{mode:'work'}],['boop_context',{targetSessionId:'target'}]]){
    const def=defs.get(name), result=await def.execute(args,exec)
    assert.equal(result.ok,true)
    const violations=validateJsonSchemaValue(def.output.schema,result)
    assert.ok(violations.length>0)
    assert.throws(()=>ToolRuntime.prototype.createSuccessResult.call({}, {...exec,arguments:args},def,result),/schema|property|output/i)
    console.log(JSON.stringify({probe:'R-SCHEMA',name,violations}))
  }
  w.db.close()
})

test('R-PROVENANCE: registered dispatcher treats a non-home tool call as human authorization', async () => {
  const w=world(), defs=new Map()
  applyTools({tools:{register:d=>defs.set(d.name,d)},boop:{delegation:()=>w.service,home:()=>null,storage:()=>({identity:{scopeId:'scope',ownerId:'owner'},repo:{getScope:()=>({policyEpoch:1,mainSessionId:'main'})},facts:()=>({lease:{fencingToken:1}})})},logger:{info(){},warn(){}}})
  const exec={agent:{session:{id:'ordinary-session'}},callId:'model-call-with-no-direct-user',rootCallId:'model-call-with-no-direct-user',signal:new AbortController().signal}
  const ctx=await defs.get('boop_context').execute({targetSessionId:'target'},exec)
  const out=await defs.get('boop_dispatch').execute({requestId:'request-1',targetSessionId:'target',contextToken:ctx.data.contextToken,goal:'Change project',instruction:'Apply requested changes'},exec)
  assert.equal(out.ok,true)
  const row=w.db.db.prepare('SELECT origin_message_id,main_session_id FROM action_runtime').get()
  assert.equal(row.main_session_id,'ordinary-session'); assert.equal(row.origin_message_id,exec.callId)
  console.log(JSON.stringify({probe:'R-PROVENANCE',out,stored:row,limitation:'Tool execute/host controller probe; upstream catalog/context output-schema failure is a separate blocker in the complete runtime.'}))
  w.db.close()
})

test('R-CONTEXT: old context from another main user message is accepted after target constraints change', async () => {
  const w=world(), ctx=await w.context()
  Object.assign(w.sessions.get('target'),{headSeq:9,latestDirectUserSeq:8,latestDirectUserMessageId:'new-user-do-not-change'})
  const out=await w.prepare(ctx.data.contextToken,{...w.call,originRef:'different-user-request'})
  assert.equal(out.ok,true); await w.service.tick(); assert.equal(w.calls.followup.length,1)
  console.log(JSON.stringify({probe:'R-CONTEXT',snapshotUserSeq:3,currentUserSeq:8,sent:w.calls.followup.length}))
  w.db.close()
})

test('R-REVOKE: queued command is sent after user revokes all BOOP source access', async () => {
  const w=world(); w.sessions.get('target').busy=true
  const ctx=await w.context(); const task=await w.prepare(ctx.data.contextToken); await w.service.tick()
  assert.equal(w.calls.followup.length,0)
  await w.service.setAccess({requestId:'revoke',expectedPolicyEpoch:1,mode:'none',workspaceIds:[],sessionIds:[]},{...w.call,originKind:'ui'})
  w.sessions.get('target').busy=false; await w.service.tick()
  assert.equal(w.service.readAccess().mode,'none'); assert.equal(w.calls.followup.length,1)
  console.log(JSON.stringify({probe:'R-REVOKE',access:w.service.readAccess(),taskId:task.data.taskId,sent:w.calls.followup.length}))
  w.db.close()
})

test('R-WORKSPACE: selected-workspace access permits context but rejects its dispatch', async () => {
  const w=world()
  await w.service.setAccess({requestId:'select',expectedPolicyEpoch:1,mode:'selected',workspaceIds:['ws'],sessionIds:[]},{...w.call,originKind:'ui'})
  const call={...w.call,policyEpoch:2}; const ctx=await w.context(call); assert.equal(ctx.ok,true)
  const out=await w.prepare(ctx.data.contextToken,call); assert.equal(out.ok,false); assert.equal(out.error.code,'SCOPE_DENIED')
  console.log(JSON.stringify({probe:'R-WORKSPACE',contextOk:ctx.ok,dispatch:out}))
  w.db.close()
})

test('R-STOP-REVISION: stopping revised task reports stopped while previous execution keeps its slot', async () => {
  const w=world(), ctx=await w.context(), first=await w.prepare(ctx.data.contextToken)
  await w.service.tick(); Object.assign(w.sessions.get('target'),{turnId:'owned-turn',ownership:'exclusive'}); await w.service.tick()
  w.advance(); const nextCall={...w.call,originRef:'user-request-2'}, fresh=await w.context(nextCall)
  const revised=await w.service.revise({requestId:'revise',taskId:first.data.taskId,expectedTaskVersion:1,contextToken:fresh.data.contextToken,instruction:'Also fix footer'},nextCall)
  assert.equal(revised.ok,true)
  const stopped=await w.service.stop({requestId:'stop',taskId:first.data.taskId,expectedTaskVersion:2},{...nextCall,originKind:'ui'})
  assert.equal(stopped.data.disposition,'stopped'); assert.equal(w.calls.cancel.length,0)
  const old=w.db.db.prepare('SELECT state FROM action WHERE id=?').get(first.data.actionId), slot=w.db.db.prepare('SELECT state, action_id FROM execution_slot').get()
  assert.equal(old.state,'running'); assert.equal(slot.action_id,first.data.actionId)
  console.log(JSON.stringify({probe:'R-STOP-REVISION',stopped,old,slot,cancelCalls:w.calls.cancel.length}))
  w.db.close()
})

test('R-MIXED: same command can enter twice when mixed with a human message', async () => {
  const w=world(), ctx=await w.context(), prepared=await w.prepare(ctx.data.contextToken)
  await w.service.tick()
  const port=runtimeGatePortOf({boop:{storage:()=>({db:w.db,identity:{scopeId:'scope'}}),gate:()=>({isArmed:()=>true,list:()=>[]}),proxyMessageIds:()=>[]}})
  const gate=new PreStepRuntimeGate(port)
  const command=w.calls.followup[0].message
  const messages=[command,{id:'human-1',source:{kind:'user'}}]
  const payload={agent:{id:'target'},messages,turn:1,step:1}
  const first=await gate.handle(payload,async()=>({kind:'enter',messages}))
  const admissionBefore=w.db.db.prepare('SELECT * FROM action_admission WHERE action_id=?').get(prepared.data.actionId)
  assert.equal(admissionBefore.message_id,command.id); assert.equal(admissionBefore.turn_id,'turn:1')
  const second=await gate.handle({...payload,turn:2},async()=>({kind:'enter',messages}))
  assert.equal(first.kind,'enter'); assert.equal(second.kind,'enter'); assert.equal(second.messages.some(m=>m.id===command.id),true)
  const admissionsAfter=w.db.db.prepare('SELECT * FROM action_admission WHERE action_id=?').all(prepared.data.actionId)
  assert.equal(admissionsAfter.length,1); assert.equal(admissionsAfter[0].turn_id,'turn:1')
  // Control: a pure-BOOP batch does consult its consumed set and rejects the second claim.
  const pure=new PreStepRuntimeGate(port), purePayload={...payload,messages:[command]}
  assert.equal((await pure.handle(purePayload,async()=>({kind:'enter',messages:[command]}))).kind,'enter')
  assert.equal((await pure.handle({...purePayload,turn:2},async()=>({kind:'enter',messages:[command]}))).kind,'reject')
  console.log(JSON.stringify({probe:'R-MIXED',first:first.kind,second:second.kind,secondIds:second.messages.map(m=>m.id),consumed:gate.status().consumedMessageIds,admissionBefore,admissionsAfter,pureSecond:'reject',port:'actual runtimeGatePortOf with actual SQLite action/admission rows'}))
  w.db.close()
})

test('R-NATIVE: official observation-shaped input is reduced to busy=false and no execution/result facts', async () => {
  const query={observeSession:async()=>({source:'live',header:{id:'target',origin:'subagent',parentSession:'parent'},cursor:8,events:[],projections:{},[Symbol.dispose](){}}),listEvents:async()=>[{seq:7,type:'user/message'},{seq:8,type:'turn/end'}]}
  const ctx={reflect:{get:name=>name==='sessionQuery'?query:null},boop:{storage:()=>({checkWrite:()=>({ok:true})})}}
  const ports=createDelegationPorts(ctx,'scope',()=>new Date().toISOString())
  const observation=await ports.observe('target'), events=await ports.readEvents('target',80,null)
  assert.equal(observation.busy,false); assert.equal(observation.subagent,false); assert.equal(observation.turnTerminal,false); assert.equal(observation.summary,null)
  assert.equal(await ports.visible('target','known-id'),false); assert.equal(await ports.mainIdle(),true)
  assert.deepEqual(events.map(x=>x.text),['user/message','turn/end'])
  console.log(JSON.stringify({probe:'R-NATIVE',observation,events,visible:await ports.visible('target','known-id'),mainIdle:await ports.mainIdle(),limitation:'Uses official-shaped host data, no real running DSH model.'}))
})

test('R-DELIVERY: already-claimed result is delivered again after response loss despite pending-only native dedup', async () => {
  const w=world(), ctx=await w.context(), first=await w.prepare(ctx.data.contextToken)
  await w.service.tick(); Object.assign(w.sessions.get('target'),{turnId:'turn-1',turnTerminal:true,ownership:'ended',summary:'Result',deliverable:true,evidenceSeq:8}); await w.service.tick()
  // The native inbox class is internal, so evaluate its exact installed implementation.
  // Only its Session append/projection storage and event bus are isolated substitutes.
  const pnpmDir=new URL('./repo/dsh-boop/node_modules/.pnpm/',import.meta.url)
  const packageDir=fs.readdirSync(pnpmDir).find(name=>name.startsWith('@deepseek-ai+dsh-agent-loop@0.2.1-rc.2_'))
  assert.ok(packageDir)
  const nativeBundle=fs.readFileSync(new URL(`${packageDir}/node_modules/@deepseek-ai/dsh-agent-loop/lib/index.js`,pnpmDir),'utf8')
  const begin=nativeBundle.indexOf('var ReactLoopInbox = class {'), end=nativeBundle.indexOf('//#endregion',begin)
  assert.ok(begin>=0 && end>begin)
  const NativeInbox=vm.runInNewContext(nativeBundle.slice(begin,end)+'\nReactLoopInbox')
  let state={'next-turn':[],'next-step':[]}, seq=0
  const nativeSession={id:'main',append(type,data){assert.equal(type,'agent/inbox/spliced');state={...state,[data.target]:state[data.target].toSpliced(data.start,data.removedCount??0,...data.inserted)};return{seq:seq++,type,data}}}
  const inbox=new NativeInbox({stateOf:()=>state},nativeSession,{emit(){}})
  const control={id:'dedup-control',role:'user',source:{kind:'boop-result'},content:[]}
  inbox.append('next-turn',control)
  assert.throws(()=>inbox.append('next-turn',control),/already pending/)
  assert.equal(inbox.claim('next-turn',0)[0].id,control.id)
  // Post-claim duplicates are not rejected by this exact native class.
  inbox.append('next-turn',control); inbox.claim('next-turn',1)
  let sends=0; const firstClaimed=[]; const ids=[]
  w.ports.followup=async(id,message)=>{
    assert.equal(id,'main'); sends++; ids.push(message.id); inbox.append('next-turn',message)
    if(sends===1){firstClaimed.push(...inbox.claim('next-turn',2)); throw new Error('response lost after native claim')}
    return 'enqueued'
  }
  w.ports.pending=async(id,messageId)=>inbox.nextTurn.some(message=>message.id===messageId)
  await w.service.deliver(); await w.service.deliver()
  assert.equal(sends,2); assert.equal(firstClaimed.length,1); assert.equal(inbox.nextTurn.length,1); assert.equal(firstClaimed[0].id,inbox.nextTurn[0].id)
  console.log(JSON.stringify({probe:'R-DELIVERY',sends,ids,firstAlreadyClaimed:firstClaimed.length,secondPending:inbox.nextTurn.length,pendingDuplicateControl:'rejected by exact native method',outbox:w.db.db.prepare('SELECT state,attempt FROM result_outbox').all(),limitation:'Exact installed native inbox methods with isolated projection/session storage; no real model or user messages. No claim of two same-ID messages simultaneously pending.'}))
  w.db.close()
})

test('R-REVISION-CONSTRAINTS: omitted criteria/exclusions clear old restrictions; explicit full values preserve them', async () => {
  const observations=[]
  for(const includeFullValues of [false,true]){
    const w=world(), ctx=await w.context()
    const first=await w.prepare(ctx.data.contextToken,w.call,{criteria:['标题不溢出'],exclusions:['不要部署']})
    assert.equal(first.ok,true)
    const initial=w.db.db.prepare('SELECT version,criteria_json,exclusions_json FROM task WHERE id=?').get(first.data.taskId)
    assert.deepEqual(JSON.parse(initial.exclusions_json),['不要部署'])
    w.advance()
    const nextCall={...w.call,originRef:'user-request-2'}
    const fresh=await w.context(nextCall)
    assert.equal(fresh.ok,true)
    const args={requestId:'revise-footer',taskId:first.data.taskId,expectedTaskVersion:1,contextToken:fresh.data.contextToken,instruction:'再改页脚',...(includeFullValues?{criteria:['标题不溢出'],exclusions:['不要部署']}:{})}
    const revised=await w.service.revise(args,nextCall)
    assert.equal(revised.ok,true)
    const current=w.db.db.prepare('SELECT version,criteria_json,exclusions_json FROM task WHERE id=?').get(first.data.taskId)
    const action=w.db.db.prepare('SELECT target_session_id,payload_json FROM action WHERE id=?').get(revised.data.actionId)
    const payload=JSON.parse(action.payload_json)
    assert.equal(action.target_session_id,'target'); assert.equal(payload.instruction,'再改页脚')
    assert.deepEqual(JSON.parse(current.exclusions_json),includeFullValues?['不要部署']:[])
    assert.deepEqual(JSON.parse(current.criteria_json),includeFullValues?['标题不溢出']:[])
    assert.deepEqual(payload.exclusions,includeFullValues?['不要部署']:undefined)
    assert.deepEqual(payload.criteria,includeFullValues?['标题不溢出']:undefined)
    observations.push({includeFullValues,initial,current,newActionPayload:payload,dispatchEffectiveExclusions:payload.exclusions??[]})
    w.db.close()
  }
  console.log(JSON.stringify({probe:'R-REVISION-CONSTRAINTS',observations,limitation:'Fresh same-target context, actual persisted controller writes only. No model or real native dispatch.'}))
})
