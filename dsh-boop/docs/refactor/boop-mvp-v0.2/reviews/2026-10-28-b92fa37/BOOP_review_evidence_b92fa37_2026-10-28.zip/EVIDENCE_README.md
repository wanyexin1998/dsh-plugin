# BOOP 审查证据复现包

结论和边界见 `BOOP_review_b92fa37_2026-10-28.md`。目标 `b92fa37ed67182916e133e5e60b4b970a858d5e8`；基线 `6f9c046681e58a1304704baf165dce5de2a49f4f`。所有产品源码只读，未向 GitHub 写入。

## 文件说明

- `findings.json`：25 项最终发现，含严重度、可达性、代码位置、证明、修复、验收及原编号映射。
- `review-manifest.json`：环境、总数、测试结果、62 文件覆盖。
- `frontend-round1.md`、`runtime-round1.md`、`persistence-round1.md`：首轮分工报告，后续有追加。
- `cross-*-review.md`：第三轮独立反证。历史表述以最终报告和最新探针为准。
- `runtime-probes.mjs`：10 项；使用正式 inbox 的已消费后重投对照已补强。
- `frontend-validation.mjs`：5 项。
- `persistence-adversarial.mjs`：5 项（含 PERSIST-5 原生消息结构）。
- `review-error-path.mjs`：1 项（失败后列表清空）。上述 21 项互不重复。
- `cross-frontend-validation.mjs`：独立加强持久化 3 项，输出 cross-frontend-validation.json。
- `cross-frontend-recheck.mjs`：独立复核前端 5 项，输出 cross-runtime-frontend-results.json。
- `unit-direct/`、`client-direct/`：逐文件真实运行日志。
- `SHA256SUMS.json`：包内其他文件的完整性清单。

## 重要：这些是“缺陷成立”的复现断言

对被审查 SHA，脚本 exit 0 表示错误被成功复现。修复后不要照搬这些反向断言作为 CI 验收；应改成期望安全/正确行为，同时保留正常对照。所有 native 外部副作用均隔离在测试替身或调用捕获点，没有模型、真实会话或用户数据操作。

## 固定版本准备

需要 Linux Node 24.22.1（SQLite 支持）、pnpm 11.25.0 和 Git。以下命令从解压目录执行，保持 repo/ 与 baseline/ 为兄弟目录。

```bash
git clone https://github.com/wanyexin1998/dsh-plugin.git repo
git -C repo checkout --detach b92fa37ed67182916e133e5e60b4b970a858d5e8
git -C repo worktree add --detach ../baseline 6f9c046681e58a1304704baf165dce5de2a49f4f
cd repo/dsh-boop
pnpm install --frozen-lockfile --ignore-scripts
node build.mjs
cd ../..
node frontend-validation.mjs
node persistence-adversarial.mjs
node runtime-probes.mjs
node review-error-path.mjs
node cross-frontend-validation.mjs
node cross-frontend-recheck.mjs
```

文件读取和源码抽取依赖固定提交及锁文件中的正式 rc.2 包。换成不同版本前先核对提取定位，不要把定位失效当成产品修复。若运行器对子进程、SQLite 或 localhost 有限制，记录环境原因并在允许的隔离环境重跑；不得删除测试来制造通过。

## 构建与原有测试

在 `repo/dsh-boop` 执行：

```bash
node build.mjs
node node_modules/typescript/bin/tsc --noEmit
```

逐文件执行测试（不要因一个失败中止全部文件）：

```bash
for test_file in tests/unit/*.test.mjs; do node "$test_file"; done
for test_file in tests/client/*.test.mjs; do node "$test_file"; done
node tools/package-boop.mjs --out dist/review-b92fa37 --json
```

基线类型比较使用与目标完全相同的 node_modules；本次在 baseline/dsh-boop 建立了指向目标依赖目录的符号链接。路径/诊断 code/message 相同而只有行号移动的错误不算新增。结果为 baseline 194、head 231、40 新增/3 消失。

## 结果解读

- unit-direct-results.json 是最终单元结果：292/292。
- client-direct-results.json 是已加载 7 文件的 79 项结果：76 通过/3 失败，另 1 文件加载错误独立记录。
- build-authorized-result.json 是排除沙箱进程限制后的最终构建结果。
- 初次 build-result.json/unit-result.json 保留来解释环境失败，不替代最终结果。
- package-verification-result.json exit 1 的原因是旧 100 KB 阈值，不是缺少 bundle；没有发布。
- 未做真实模型/Windows/rc.3/完整浏览器输入验收。

## 中间报告编号映射

以 findings.json.originalIds 对照最终 R01–R25。cross-persistence-review 的早期投递反证已经通过新 R-DELIVERY 探针解决；最终限定是“第一次已被 claim 后重投”，不是“两个相同 ID 同时 pending”。R-REVISION-CONSTRAINTS 是第 10 个 runtime 探针；文件中的 9 项旧计数代表较早一轮。
