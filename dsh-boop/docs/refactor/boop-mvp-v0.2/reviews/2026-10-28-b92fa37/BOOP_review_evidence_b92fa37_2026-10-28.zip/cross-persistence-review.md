# 第 3 轮交叉反证：持久化审查者复核运行时候选

固定提交：`b92fa37ed67182916e133e5e60b4b970a858d5e8`。

独立读取了 `runtime-probes.mjs`、`runtime-probes.log`，对照产品实际装配、工具注册、正式 DSH rc.2 runtime / SessionQuery / AgentInbox 契约。重新执行 `node runtime-probes.mjs`，9 个故障断言均通过。本轮的关键工作是限制结论边界：直接调用 controller 的失败，不等于当前完整插件已经触发真实执行。

## 裁定表

| 候选 | 裁定 | 本轮确认的事实与限制 |
| --- | --- | --- |
| R-SCHEMA：catalog/context输出schema不兼容 | **CONFIRM** | 当前工具调用立即可达。正式 ToolRuntime.dispatchToolBody 必然在 execute 后调用 createSuccessResult；后者先 validateJsonSchemaValue，再 render。新 envelope 的 schemaVersion/kind/ok/data 均被 additionalProperties:false 拒绝。修改 render 分支无法回避验证。 |
| 生产未调用 tick / deliver | **CONFIRM** | 全 src 的 tick/deliver 检索只有 DelegationService 定义。prepare 仅写 planned/prepared；bootRecover 只恢复slot；页面轮询只读 list/detail；reconcile 不发新命令。旧 Dispatcher 在 api-service PoC 入口且 shipped pocEnabled 默认关闭。没有找到可推翻“当前委托不会推进/结果不会自动回传”的生产路径。 |
| R-CONTEXT：过期语义快照仍派工 | **REVISE：保留为 controller latent 缺陷** | prepare只核对target/main/TTL/epoch，没有核对snapshot.origin_message_id、source_generation/head_seq/latest_user_seq/latest_user_message_id与当前事实；反而把新的 observed.latestDirectUserSeq 写入runtime，tick就看不到自context读取以来的变化。测试证明正式controller接受了旧快照并向port发命令；当前schema失败和tick未接线遮住完整生产派工，不能写成“已在真实会话执行”。 |
| R-REVOKE：撤销范围后仍派发 | **REVISE：保留为 controller latent 缺陷** | tick/claim/sendClaimed没有重新检查canRead、最新policy epoch或本进程fence。fixture先busy排队、调用setAccess(mode:none)、再解除busy，其后followup=1，测试有效。但setAccess本身也没有remote/UI调用方，不应宣称当前用户已经能通过页面撤销后被越权执行。必须同时补权限UI与执行边界检查，不能只给tick接线。 |
| R-PROVENANCE：非主页/非直接用户工具调用成为授权 | **REVISE：工具边界缺陷确证，完整越权执行未证实** | trustedCall把callId兜底成originRef并硬写originKind:user，无主会话绑定与直接用户来源验证。真实工具定义的execute对ordinary-session通过，真实DB写出了其action_runtime。根patch还注册了全局boop-tools。脚本没有走真实Agent工具可见性与完整工具runtime，且context输出schema会挡住模型取得token；不要把controller证据扩写为当前已有完整攻击利用。 |
| R-WORKSPACE：选工作区可读不可派 | **REVISE：controller latent 缺陷** | readContext用observed.workspaceId，prepare却canRead(target,null)，因此workspaceIds权限不生效。测试数据是合法的DelegationPorts契约；但生产adapter又把workspaceId错误默认null，UI也没有setAccess入口，完整真实路径尚未验证。 |
| R-STOP-REVISION：新revision停止后旧action继续 | **REVISE：controller latent 缺陷** | stop只找latestAction；新版planned被停止后提前返回stopped，没有处理占slot的旧running action。脚本清楚证明DB/取消port行为。真实运行态是fixture通过手动tick构造，当前生产链无法自然进入该状态，报告需保留这层前提。 |
| R-MIXED：混合消息重复放行 | **REVISE：门禁防重复不变量破坏，重复真实执行未证实** | handleMixed允许分支漏写consumed；正式recordAdmission是ON CONFLICT DO NOTHING，v2AdmissionAllows只查action状态，也不能阻止第二次放行。fixture同一个batch调用两次能证明该防线缺失。它没有证明DSH会无条件再次claim同一消息；上游重放条件和真正第二次执行应另验。 |
| R-NATIVE：正式宿主数据映射错误/常量stub | **CONFIRM，收窄busy样例表述** | 正式SessionObservation用source，不含live；SessionHeader子会话标记是parentSession/origin；SessionEventRecord.surface是字符串current/shadowed/log-only，不是{text}。readEvents实际只能得到事件类型。turnId、terminal、ownership、result、mainIdle、visible仍常量。fixture确证映射丢失；其中fixture最后一个事件是turn/end，并不能单独证明该fixture正忙，busy问题应引用契约及任何真实运行中的session都会没有header.running/observed.live这一静态链路。 |
| R-DELIVERY：unknown回传再次投递 | **REVISE：重复调用确证，两个同时pending的原复现不符合真实宿主** | deliver会选unknown，再followup，未先查pending，visible还恒false；故盲目重投行为成立。但正式AgentInbox只针对当前next-turn/next-step拒绝重复id，原数组fixture允许两个同id同时pending，不能当作真实行为。已消费历史不在该去重范围，若首条结果已被消费而响应丢失，重投才可能第二次进入历史。该实际条件需补测试；当前deliver未接线仍遮住生产路径。 |

## 首要四项的代码依据

### 输出 schema：不是测试仅绕过了真实 runtime

产品 `src/host/tools.ts` 的新 catalog 返回分支在 `106-127`，schema仍是 `77-93`；新 context 返回分支 `260-280`，schema仍是 `237-249`。正式 `@deepseek-ai/dsh-tools/lib/index.js` 的 `dispatchToolBody`：

```js
const returned = await tool.execute(exec.arguments, exec)
const result = this.createSuccessResult(exec, tool, returned)
```

`createSuccessResult` 先执行 schema 校验，非空violations抛ToolOutputError，其后才render。原probe调用此正式方法时错误发生在需要完整this/runtime状态之前，因此使用prototype.call并没有制造假阳性。主审还应保存错误类型，而不只匹配message正则。

### 未接线的调用链

模型 `boop_dispatch.execute → DelegationService.prepare → DB planned/prepared → return queued`。`tick → tickOnce → claim → sendClaimed` 以及 `deliver → followup(main)` 各自存在，但代码中没有生产入口连接它们。没有把“没看到timer”简单当作证据：已额外排查 `ctx.effect`、scheduler drain、reconcile、旧Dispatcher与构建lib。

### 快照变化被新的 observed 覆盖

`service.ts:407-425` 查token与基本属性后读取当前target，未比较token中的用户消息和head；`455` 写入当前observed而非已核验的snapshot watermark；`506` 的二次检查便只会比较同一个新值。修复应比较原snapshot，再在发送前核对同一上下文与policy；不能只把runtime的值换成旧值后让请求永远排队，也需要明确向用户说明要重新读取。

### 撤销和fence均应在实际副作用边界核验

入口prepare的fence检查不能代替等待队列以后检查。`tickOnce:482-524`、`claim:1017-1039`、`sendClaimed:527-542` 都没有基于最新权限/epoch/本进程holder-token的拒绝。测试只是将busy当作异步等待边界，模拟合理。当前没有setAccess UI是另一项未完成交付，不能用它解释为控制器无需保护。

## 独立发现的追加候选

`revise()` 在 `service.ts:762,768-771` 对未提供的criteria/exclusions写成空数组。用户只说“再调整页脚”时，原“不要部署”等限制会丢失。已交运行时审查者在现有revision fixture中补证；同属controller latent，未声称当前已真正部署。

## 对本审查者首轮发现的进一步反证

### PERSIST-3 的影响边界需要保留

已使用正式 SessionReferenceResolver.prepareDirectMessages 证明 deny-all 后仍消费内层secret URI，因此确实绕过到原生预读取。**没有证明真实模型已收到秘密或外传**。之后注入的guard notice缺id/role可能让Agent append失败；实际 native自动读取发生在这个失败之前，二者不是互相抵消。

当前source_access切换还没有UI/remote入口，所以PERSIST-3所需none/selected/unknown策略前提应明确列出，不能说默认all_authorized的页面已经出现“越过none设置”的现象。

### 新补证 PERSIST-5 / P2：拒绝引用通知不符合正式消息协议

位置 `src/host/home/reference-guard.ts:84-87`。通知只有source/content，无id和role。正式 AgentLoop 将 decision.messages 逐个作为 `user/message` append；正式 Session 验证非空id、role:user。已在 `persistence-adversarial.mjs` 加入验证：相同合法surfaceOp:'append'下，原用户消息通过 `snapshotSessionEvent`，guard通知失败：`lacks an identified message`。

因此普通被拒绝/unknown引用也会令这一轮聊天失败。修复需使用原生message factory生成合法、稳定id的解释消息，或在原用户文本中追加无引用解释，不能手拼不完整UserMessage。验收需要真实session append，不只检查文本里URI消失。

## 未作出的结论

- 不称9个probe等于9个真实DSH E2E通过。
- 不称所有controller漏洞已在当前UI可触发；未接线本身是已证实的主流程缺陷。
- 不称模拟数组重复收消息证明正式宿主会同时pending重复id。
- 不把“缺真实模型/Windows测试”直接写成安全漏洞；这些是剩余验证范围。
