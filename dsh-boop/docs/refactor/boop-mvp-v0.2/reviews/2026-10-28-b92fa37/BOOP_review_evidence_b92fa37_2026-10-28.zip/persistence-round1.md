# BOOP 对抗审查：持久化 / Home / 引用范围（第 1 轮）

- 审查基线：`6f9c046681e58a1304704baf165dce5de2a49f4f`
- 固定目标：`b92fa37ed67182916e133e5e60b4b970a858d5e8`
- 方法：变更代码与上下游逐项阅读；Node 24.22.1、真实 SQLite / schema-1 → schema-2 迁移；正式 DSH rc.2 引用解析器及引用准备方法。未连接真实模型，未改产品源码，未提交。
- 可执行复现：`persistence-adversarial.mjs`
- 输出：`persistence-adversarial-results.json`
- 执行：在本报告所在目录运行 `node persistence-adversarial.mjs`。
- 专用安全扫描技能的预检资源不可用；本报告为手动审查及针对性验证，不声称正式扫描流程完成。

## 已复现的独立问题

### PERSIST-1 / P1：旧用户升级后会有两个互相矛盾的主会话身份

**位置**：`dsh-boop/src/host/home/service.ts:150-166`，最窄缺陷位置 `158-164`。

`HomeService.binding()` 只查询新增的 `home_binding_history`。schema-1 升级没有给它回填旧 `scopes.main_session_id`。所以旧用户首次进入新主页会创建一个新 UUID Session。`bind()` 只在 `scopes.main_session_id` 为空或已经是新 UUID 时更新它，然而没有检查 `UPDATE ... changes`；旧值非空时更新 0 行，仍插入新的当前绑定历史并返回 `ready`。

**实际复现**：用基线 `V1Database` 创建真实 v1 库，`bindMainSession(scope, 'boop-main')`，关闭后由新 `BoopStorage.start()` 完成实际迁移，再调用产品 `HomeService.ensureHome()`。结果：

- schema 为 2，迁移成功；
- `scopes.main_session_id` 仍为 `boop-main`；
- `home_binding_history` 当前行 / `ensureHome.data.mainSessionId` 为新 `boop-home-<UUID>`；
- 回包为 `ready`，未报冲突。

**影响**：新主页、旧 main-session API、scheduler / UI mutation context 对“波波主会话”使用不同身份。旧身份未成为明确历史项，用户既有聊天无法按设计延续。后续修复授权校验时，该不一致还会导致合法主页调用被拒绝。

**反证检查**：`schema-v2.ts` 只创建 history 表，没有填充旧绑定；`HomeService` 从未使用 provisioning 中预留的 `legacy_session_id`，插入 history 时 `previous_session_id` 也为 NULL。不能假设“会自动迁移旧绑定”。不能声称本次已证明所有派工都会拒绝：当前 model tool 反而缺失严格主会话校验，那是运行时审查的另一项问题。

**修复与验收**：升级时识别旧绑定，检查真实 preset/cwd/运行态，根据 ADR 复用或转历史；一个事务内对 scopes/history 做实际 CAS，更新 0 行必须回滚并报需要恢复，不得返回 ready。测试必须使用真实 v1 非空绑定，断言 scopes、当前 history、home 返回值一致，历史保留且旧会话不被强停。

### PERSIST-2 / P1：新读取适配器绕过现存“排除 / 忘记”规则

**位置**：`dsh-boop/src/host/home/native-session.ts:178-179`。

生产 `createDelegationPorts()` 的 `excluded()` 固定返回 false，`hostCanRead()` 固定返回 true。`DelegationService.canRead()` 的第一道排除检查因此永远不会触发。旧库的 `forget_rule(mode='exclude_source'/'exclude_scope')` 和 `source_cursor.state='excluded'` 没有接入新 policy；新 `source_access` 又由 `inheritAccess()` 默认写为 `all_authorized`。

**实际复现**：真实 schema-2 SQLite 中插入 `secret-session` 的 `exclude_source` rule 和 `excluded` cursor，构造真实生产 ports 与 DelegationService 并执行正常启动的 `inheritAccess()`。`canRead('secret-session', null)` 返回 allow；`gateHomeReferences()` 保留其 canonical mention；正式 DSH parser 仍把它识别成需要读取的 session。

**影响**：升级后用户此前明确排除的来源重新进入候选、上下文、native 引用读取路径。即使旧记忆提取模块仍遵守 forget rules，也无法保护新路径。

**反证检查**：旧规则不是被迁移删掉，而是存在却未读取；只改 `source_access` 表中 mode 的测试无法覆盖该问题。本次没有证明任意宿主 ACL 绕过，后者需要宿主授权模型；已证明的是 BOOP 自己明确的旧排除规则失效。

**修复与验收**：统一 policy 从权威旧/新排除与忘记记录读取结果；unknown 时封闭。旧规则迁移明确保留，不能把缺少新表行视为撤销旧限制。用真实 v1 / v2 exclusion fixtures 同时验证 catalog/context/dispatch/native reference 无读取；清除规则只能由有权用户显式操作。

### PERSIST-3 / P1：被拒绝引用的标签可以产生新的 URI，绕过 deny-all

**位置**：`dsh-boop/src/host/home/reference-guard.ts:68-77`，关键为 `70-71`。

guard 解析一次 canonical mention，把被拒绝引用降级成 `parsed.text`。这个文本保留用户控制的 label；当 label 本身含一个 canonical `dsh-session:` URI 时，降级结果仍是宿主会读取的合法引用。官方 `SessionReferenceResolver` 的 prepended pre-step 在 `await next()` 后对 guard 输出再次运行 parser，因此出现第二次解释。

**实际复现输入**：

```text
@[dsh-session:InNlY3JldC1zZXNzaW9uIg](dsh-session:ImJsb2NrZWQtb3V0ZXIi)
```

外层 session 是 `blocked-outer`；label 内 URI 是 `secret-session`。设置 policy `decide: () => 'deny'` 后：

```text
guard 输出：@dsh-session:InNlY3JldC1zZXNzaW9uIg
正式宿主 parser / prepareDirectMessages 消费：secret-session
```

复现直接调用已安装正式 rc.2 `SessionReferenceResolver.prototype.prepareDirectMessages`，只把最终 `prepare()` 内容读取替换成捕获 spy，不伪造其两阶段解析。无需模型，也无需外部网络。

**影响**：用户粘贴这样的文字、或候选 label/会话名称含 URI 时，即使设置“不读取任何来源”，仍可能触发原生自动上下文读取。单次 guard 调用已经足够复现，不能依赖重复注册 guard 偶然覆盖第二层解释。

**修复与验收**：对降级显示文本中的 canonical scheme 一并进行不可再解析转义/中和；必须在正式宿主 parser 上做最终 postcondition，确保被拒绝 session 的 URI 不能从 label 再生成。回归用 bare / mention / escaped label / 嵌套 label，验证 deny-all 后正式 prepare 路径不读取任何来源，同时允许的文字与附件保留。

### PERSIST-4 / P1：HomeService 在实际装配中没有接入 writer fence

**位置**：`dsh-boop/src/host/index.ts:154-161`；配套 `home/service.ts:54,65-67`。

HomeService 有 `fenceOk` 参数，但默认是始终 true，生产 `apply()` 创建它时未传 storage.checkWrite。因此即使这一个 Host 的 token 已被后继 Host 替代，新请求仍可写 home_provisioning、创建 native Session 并写绑定。

**实际复现**：运行真实 `host/index.ts apply(ctx)`（宿主服务为最小 contract double，SQLite / HomeService / wiring 真实），启动拿到 lease 后把同一库 runtime_lease 切到 successor、token +1；确认 `storage.checkWrite()` 返回 `{ok:false, reason:'fencing token superseded'}`，再调用实际暴露的 `ctx.boop.ensureHome()`。仍发生 1 次 native create，最终回包 `ready`。

**影响**：休眠 / 长阻塞 / lease 接管以后，旧进程可以在失去写控制权后创建重复主会话或争写身份数据。存储层改正确 checkWrite 对没有调用它的路径无效。

**反证检查**：启动时 `state.storage.ok` 的一次检查不能覆盖后来 lease 丢失；DelegationService 已装的 ports.fenceOk 也不会被 HomeService 自动复用。

**修复与验收**：生产构造必须传本进程 fence；每个 await 后、native side effect 前、绑定事务内再次校验真实 holder/token，不能只在方法入口检查。测试 lease 在 ensureHome 前和 native create/flush await 中途被接管；旧 Host 不产生新的 native side effect，也不能提交 ready 绑定。已有 native create 但丢 fence 的情况保留 provisioning evidence，交给恢复，不盲目重建。

## 其他已检查、暂不作为独立确证缺陷的点

1. `modelAvailable()` 查不存在的 `ctx.modelDirectory/ctx.models`；正式 rc.2 使用 `ctx.llm.listProviders/listModels/resolveModelInfo`。已交给主审 / 前端审查确认其实际用户后果，避免重复。
2. native `observeSession` 的正式结构是 `{source:'live'|'prepared', header,cursor,events,projections}`，不是 `{live:true}`；adapter busy 判定失效。正式子会话字段为 `header.parentSession/origin`，不是 `parentSessionId`。已交运行时审查纳入完整端口复现。
3. guard 只在 ensureHome 的 verifyExisting 后注册，没有 `agent-created` 安装路径；从普通历史入口恢复 BOOP agent 后是否能在 ensureHome 前运行需真实宿主生命周期验证。注册也未去重/保存 disposer。先记 coverage gap，避免把潜在顺序问题等同已证实泄露。
4. bootstrap 对旧库调用 ensureSubjectKey/installFts 在迁移备份/lease之前；v1当前基线已有subject_key，未证明正常v1 upgrade丢数据，因此不作为新的 P1。未来版本判断能拒绝不兼容schema，但 constructor 先设置WAL，并非真正全程只读。
5. `retireOwned()` 以 title marker 匹配并忽略 delete返回code；未发现生产 schedule.delete 的可达失败样例。没有夸大成已删除别人的任务。
6. schema-v2 migration 对原始6列task_target使用事务内重建并比较行数/集合；v1实际迁移已在复现 PERSIST-1 成功，未发现该正常路径丢行。
7. `inspect()` 允许空字符串schema_version转换成0而不是corrupt，但本轮未扩展该低优先级metadata异常验证。

## 覆盖清单

以下16个分配的变更文件已读其所有变更、必要完整实现和调用关系：

| 文件 | 审查内容 |
| --- | --- |
| `src/host/persistence/database.ts` | inspect/bootstrap/write/backup/integrity |
| `src/host/persistence/migrate.ts` | 版本判断/备份/原子迁移/读回 |
| `src/host/persistence/repository.ts` | ensureScope变更、旧主绑定、forget/cursor支持 |
| `src/host/persistence/schema-v2.ts` | 新表约束、task_target重建、slot回填 |
| `src/host/persistence/schema.ts` | 版本变更、旧表结构 |
| `src/host/persistence/storage.ts` | lease/start/migration/fence/disposal |
| `src/host/home/service.ts` | provisioning/identity/guard/bind全链路 |
| `src/host/home/native-session.ts` | 全部生产ports及正式API契约对照 |
| `src/host/home/reference-guard.ts` | 解析/降级/注册及正式parser二次解释 |
| `src/host/host-identity.ts` | 真实安装身份、unknown回退 |
| `src/host/index.ts` | 服务装配/lease/fence/启动恢复顺序 |
| `src/host/scheduler.ts` | 新retireOwned与原bind/unbind比较 |
| `src/host/scheduler-api.ts` | 启动调用retireOwned路径 |
| `tests/unit/mvp-home.test.mjs` | 仅fresh identity happy path、遗漏旧绑定/fence |
| `tests/unit/host-identity.test.mjs` | unknown commit预期 |
| `tests/unit/e01-01-ledger.test.mjs` | migration测试仅fresh v2 no-op |

相关未改文件：persistence/lease.ts、main-session.ts、observe/observer.ts、api-service部分、tasks-api、tools、delegation.service、shared/session-mention及正式DSH session-reference/query/llm契约。没有把未改的整个repository/scheduler功能宣称为完整审查。
